// PSDFile.h
#define	noErr	0

#pragma pack(push,2)

typedef struct _PSDFileHeader {
	char			Signature[4];
	WORD			nVersion;
	char			Reserved[6];
	WORD			nPlaneCount;
	ULONG			dwRow;
	ULONG			dwColumn;
	WORD			nBits;
	WORD			nMode;
	char			Nothing[12];
	WORD			nCompression;
} PSDFILEHEADER;

#pragma pack(pop)

SWORD	SavePSDfile(LPVOID pInData, LPSTR pFileName, ULONG dwXPixel, ULONG dwYPixel, SWORD nImageMode, SWORD nPlaneCount, SWORD nDataType);
void	MakePSDHeader(PSDFILEHEADER *pstFileHeader, ULONG dwXPixel, ULONG dwYPixel, SWORD nImageMode, SWORD nPlaneCount, SWORD nDataType);
SWORD	PSDSave(char *pFileName, PSDFILEHEADER *pstFileHeader, ULONG dwImageSize, void *pInData);
ULONG	ConvertEndian(ULONG InLong);

///////////////////EOF///////////////////////
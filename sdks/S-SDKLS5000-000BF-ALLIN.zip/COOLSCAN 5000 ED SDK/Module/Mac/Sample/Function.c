//================================================================================================
// Copyright Nikon Corporation - All rights reserved
//
// View this file in a non-proportional font, tabs = 3
//================================================================================================

#define _WINDOWS

#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <math.h>
#include "maid3.h"
#include	"MDSample.h"

//------------------------------------------------------------------------------------------------
//
SLONG CallMAIDEntryPoint( 
		LPNkMAIDObject	pObject,				// module, source, item, or data object
		ULONG				ulCommand,			// Command, one of eNkMAIDCommand
		ULONG				ulParam,				// parameter for the command
		ULONG				ulDataType,			// Data type, one of eNkMAIDDataType
		NKPARAM			data,					// Pointer or long integer
		LPNKFUNC			pfnComplete,		// Completion function, may be NULL
		NKREF				refComplete )		// Value passed to pfnComplete
{
	return (*(LPMAIDEntryPointProc)g_pMAIDEntryPoint)( 
						pObject, ulCommand, ulParam, ulDataType, data, pfnComplete, refComplete );
}
//------------------------------------------------------------------------------------------------
//
BOOL Load_Module( char* Path )
{
	HINSTANCE hInst = LoadLibrary(Path);		//	Load LS4000.MD3

	if (hInst) {
		g_pMAIDEntryPoint = (LPMAIDEntryPointProc)GetProcAddress( hInst, "MAIDEntryPoint" );	//	Get entry function of LS4000.MD3
		if (!g_pMAIDEntryPoint)
			printf("MAIDEntryPoint cannot be found.\n"); 
	} else {
		g_pMAIDEntryPoint = NULL;
		printf("\"%s\" cannot be opened.\n", Path ); 
	}

	return (hInst != NULL) && (g_pMAIDEntryPoint != NULL);
}
//------------------------------------------------------------------------------------------------
//
BOOL Open_Object( NkMAIDObject* pParentObj, NkMAIDObject* pChildObj, ULONG ulChildID )
{
	SLONG lResult = CallMAIDEntryPoint( pParentObj, kNkMAIDCommand_Open, ulChildID, 
									kNkMAIDDataType_ObjectPtr, (NKPARAM)pChildObj, NULL, NULL );
	return lResult == kNkMAIDResult_NoError;
}
//------------------------------------------------------------------------------------------------
//
BOOL Close_Object( LPNkMAIDObject pObject )
{
	SLONG nResult = CallMAIDEntryPoint( pObject, kNkMAIDCommand_Close, 0, 0, 0, NULL, NULL );

	return nResult == kNkMAIDResult_NoError;
}
//------------------------------------------------------------------------------------------------
//
BOOL Close_Module( LPRefObj pRefMod )
{
	SLONG nResult;
	LPRefObj pRefSrc, pRefItm, pRefDat;
	ULONG i, j, k;

	if(pRefMod->pObject != NULL)
	{
		for(i = 0; i < pRefMod->ulChildCount; i ++)
		{
			pRefSrc = GetRefChildPtr_Index( pRefMod, i );
			for(j = 0; j < pRefSrc->ulChildCount; j ++)
			{
				pRefItm = GetRefChildPtr_Index( pRefSrc, j );
				for(k = 0; k < pRefItm->ulChildCount; k ++)
				{
					pRefDat = GetRefChildPtr_Index( pRefItm, k );
					nResult = Close_Object( pRefDat->pObject );
					free(pRefDat->pObject);
					free(pRefDat->pCapArray);
					free(pRefDat);//
					pRefDat = NULL;//
				}
				nResult = Close_Object( pRefItm->pObject );
				free(pRefItm->pObject);
				free(pRefItm->pRefChildArray);
				free(pRefItm->pCapArray);
				free(pRefItm);//
				pRefItm = NULL;//
			}
			nResult = Close_Object( pRefSrc->pObject );
			free(pRefSrc->pObject);
			free(pRefSrc->pRefChildArray);
			free(pRefSrc->pCapArray);
			free(pRefSrc);//
			pRefSrc = NULL;//
		}
		nResult = Close_Object( pRefMod->pObject );
		if (nResult == false )
			return false;
		free(pRefMod->pObject);
		pRefMod->pObject = NULL;

		free(pRefMod->pRefChildArray);
		pRefMod->pRefChildArray = NULL;
		pRefMod->ulChildCount = 0;
	
		free(pRefMod->pCapArray);
		pRefMod->pCapArray = NULL;
		pRefMod->ulCapCount = 0;
	}

	return true;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void InitRefObj( LPRefObj pRef )
{
	pRef->pObject = NULL;
	pRef->lMyID = 0x8000;
	pRef->pRefParent = NULL;
	pRef->ulChildCount = 0;
	pRef->pRefChildArray = NULL;
	pRef->ulCapCount = 0;
	pRef->pCapArray = NULL;
}
//------------------------------------------------------------------------------------------------------------------------------------
// issue async command while wait for the CompletionProc called.
void IdleLoop( LPNkMAIDObject pObject, ULONG* pulCount, ULONG ulEndCount )
{
	while( *pulCount < ulEndCount ) {
		Command_Async( pObject );
		Sleep(10);
	}
}
//------------------------------------------------------------------------------------------------------------------------------------
// enumerate capabilities belong to the object that 'pObject' points to.
BOOL EnumCapabilities( LPNkMAIDObject pObject, ULONG* pulCapCount, LPNkMAIDCapInfo* ppCapArray, LPNKFUNC pfnComplete, NKREF refComplete )
{
	SLONG nResult;

	do {
 		// call the module to get the number of the capabilities.
		ULONG	ulCount = 0L;
		LPRefCompletionProc pRefCompletion;
		pRefCompletion = malloc( sizeof(RefCompletionProc) );
		pRefCompletion->pulCount = &ulCount;
		pRefCompletion->pRef = NULL;
		nResult = CallMAIDEntryPoint(	pObject,
												kNkMAIDCommand_GetCapCount, 
												0,
												kNkMAIDDataType_UnsignedPtr,
												(NKPARAM)pulCapCount,
												(LPNKFUNC)CompletionProc,
												(NKREF)pRefCompletion );
		IdleLoop( pObject, &ulCount, 1 );
 
 		if ( nResult == kNkMAIDResult_NoError )
 		{
 			// allocate memory for the capability array
 			*ppCapArray = (LPNkMAIDCapInfo)malloc( *pulCapCount * sizeof( NkMAIDCapInfo ) );
  
 			if ( *ppCapArray != NULL )
 			{
 				// call the module to get the capability array
   				ulCount = 0L;
				pRefCompletion = malloc( sizeof(RefCompletionProc) );
				pRefCompletion->pulCount = &ulCount;
				pRefCompletion->pRef = NULL;
				nResult = CallMAIDEntryPoint(	pObject,
														kNkMAIDCommand_GetCapInfo,
														*pulCapCount,
														kNkMAIDDataType_CapInfoPtr,
														(NKPARAM)*ppCapArray,
														(LPNKFUNC)CompletionProc,
														(NKREF)pRefCompletion );
				IdleLoop( pObject, &ulCount, 1 );

 				if (nResult == kNkMAIDResult_BufferSize)
 				{
					free( *ppCapArray );
					*ppCapArray = NULL;
				}
			}
		}
	}
	// repeat the process if the number of capabilites changed between the two calls to the module
	while (nResult == kNkMAIDResult_BufferSize);

	// return TRUE if the capabilities were successfully enumerated
	return (nResult == kNkMAIDResult_NoError || nResult == kNkMAIDResult_Pending);
}
//------------------------------------------------------------------------------------------------------------------------------------
// enumerate child object
BOOL EnumChildrten(LPNkMAIDObject pobject)
{
	SLONG nResult;
	ULONG	ulCount = 0L;
	LPRefCompletionProc pRefCompletion;
	pRefCompletion = malloc( sizeof(RefCompletionProc) );
	pRefCompletion->pulCount = &ulCount;
	pRefCompletion->pRef = NULL;
	nResult = CallMAIDEntryPoint(	pobject,
											kNkMAIDCommand_EnumChildren, 
											0,
											kNkMAIDDataType_Null,
											(NKPARAM)NULL,
											(LPNKFUNC)CompletionProc,
											(NKREF)pRefCompletion );
	IdleLoop( pobject, &ulCount, 1 );

	return ( nResult == kNkMAIDResult_NoError );
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL Command_CapGetArray(LPNkMAIDObject pobject, ULONG ulParam, ULONG ulDataType, NKPARAM pData, LPNKFUNC pfnComplete, NKREF refComplete )
{
	SLONG nResult;
	ULONG	ulCount = 0L;
	LPRefCompletionProc pRefCompletion;
	pRefCompletion = malloc( sizeof(RefCompletionProc) );
	pRefCompletion->pulCount = &ulCount;
	pRefCompletion->pRef = NULL;
	nResult = CallMAIDEntryPoint(	pobject,
											kNkMAIDCommand_CapGetArray,
											ulParam,
											ulDataType,
											pData,
											(LPNKFUNC)CompletionProc,
											(NKREF)pRefCompletion );
	IdleLoop( pobject, &ulCount, 1 );

	return (nResult == kNkMAIDResult_NoError);
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL Command_CapGetDefault(LPNkMAIDObject pobject, ULONG ulParam, ULONG ulDataType, NKPARAM pData, LPNKFUNC pfnComplete, NKREF refComplete )
{
	SLONG nResult;
	ULONG	ulCount = 0L;
	LPRefCompletionProc pRefCompletion;
	pRefCompletion = malloc( sizeof(RefCompletionProc) );
	pRefCompletion->pulCount = &ulCount;
	pRefCompletion->pRef = NULL;
	nResult = CallMAIDEntryPoint(	pobject,
											kNkMAIDCommand_CapGetDefault,
											ulParam,
											ulDataType,
											pData,
											(LPNKFUNC)CompletionProc,
											(NKREF)pRefCompletion );
	IdleLoop( pobject, &ulCount, 1 );

	return (nResult == kNkMAIDResult_NoError);
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL Command_CapGet(LPNkMAIDObject pobject, ULONG ulParam, ULONG ulDataType, NKPARAM pData, LPNKFUNC pfnComplete, NKREF refComplete )
{
	SLONG nResult;
	ULONG	ulCount = 0L;
	LPRefCompletionProc pRefCompletion;
	pRefCompletion = malloc( sizeof(RefCompletionProc) );
	pRefCompletion->pulCount = &ulCount;
	pRefCompletion->pRef = NULL;
	nResult = CallMAIDEntryPoint(	pobject,
											kNkMAIDCommand_CapGet, 
											ulParam,
											ulDataType,
											pData,
											(LPNKFUNC)CompletionProc,
											(NKREF)pRefCompletion );
	IdleLoop( pobject, &ulCount, 1 );

	return ( nResult == kNkMAIDResult_NoError );
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL Command_CapSet(LPNkMAIDObject pobject, ULONG ulParam, ULONG ulDataType, NKPARAM pData, LPNKFUNC pfnComplete, NKREF refComplete )
{
	SLONG nResult;
	ULONG	ulCount = 0L;
	LPRefCompletionProc pRefCompletion;
	pRefCompletion = malloc( sizeof(RefCompletionProc) );
	pRefCompletion->pulCount = &ulCount;
	pRefCompletion->pRef = NULL;
	nResult = CallMAIDEntryPoint(	pobject,
											kNkMAIDCommand_CapSet, 
											ulParam,
											ulDataType,
											pData,
											(LPNKFUNC)CompletionProc,
											(NKREF)pRefCompletion );
	IdleLoop( pobject, &ulCount, 1 );

	return ( nResult == kNkMAIDResult_NoError );
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL Command_CapStart(LPNkMAIDObject pobject, ULONG ulParam, LPNKFUNC pfnComplete, NKREF refComplete)
{
	SLONG nResult = CallMAIDEntryPoint( pobject,
													kNkMAIDCommand_CapStart, 
													ulParam,
													kNkMAIDDataType_Null,
													(NKPARAM)NULL,
													pfnComplete,
													refComplete );
	return (nResult == kNkMAIDResult_NoError);
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL Command_Abort(LPNkMAIDObject pobject, LPNKFUNC pfnComplete, NKREF refComplete)
{
	SLONG nResult = CallMAIDEntryPoint( pobject,
													kNkMAIDCommand_Abort, 
													(ULONG)NULL,
													kNkMAIDDataType_Null,
													(NKPARAM)NULL,
													pfnComplete,
													refComplete );
	return (nResult == kNkMAIDResult_NoError);
}
//------------------------------------------------------------------------------------------------------------------------------------
//
SLONG Command_Async(LPNkMAIDObject pobject)
{
	return CallMAIDEntryPoint( pobject,
										kNkMAIDCommand_Async,
										0,
										kNkMAIDDataType_Null,
										(NKPARAM)NULL,
										(LPNKFUNC)NULL,
										(NKREF)NULL );
}
//------------------------------------------------------------------------------------------------------------------------------------
//
SLONG SelectDevice( LPRefObj pRefMod, LPRefObj *ppRefSrc )
{
	LPRefObj pRefSrc;
	UWORD	i, wSel;
	char	buf[256];

	// if Capability_Name is not supported, return without change
	if ( ! CheckCapabilityOperation( *ppRefSrc, kNkMAIDCapability_Name, kNkMAIDCapOperation_Get ) )
		return (*ppRefSrc)->lMyID;

	// Show last setting
	Command_CapGet( (*ppRefSrc)->pObject, kNkMAIDCapability_Name, kNkMAIDDataType_StringPtr, (NKPARAM)buf, NULL, NULL );
	printf( "Selected Device: %s\n", buf );

	// Show selectable device
	for ( i = 0; i < pRefMod->ulChildCount; i++ ) {
		pRefSrc = GetRefChildPtr_Index( pRefMod, i );
		Command_CapGet( pRefSrc->pObject, kNkMAIDCapability_Name, kNkMAIDDataType_StringPtr, (NKPARAM)buf, NULL, NULL );
		printf( "%2d. %s\n", i + 1, buf );
	}

	printf( ">" );
	scanf( "%s", buf );
	wSel = atoi( buf );
	if ( wSel > 0 && wSel <= pRefMod->ulChildCount )
		*ppRefSrc = GetRefChildPtr_Index( pRefMod, wSel - 1 );

	return (*ppRefSrc)->lMyID;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
SLONG SelectFrameNum( LPRefObj pRefSrc, LPRefObj *ppRefItm )
{
	UWORD	wSel;
	char	buf[256];

	// Show last setting
	Command_CapGet( (*ppRefItm)->pObject, kNkMAIDCapability_Name, kNkMAIDDataType_StringPtr, (NKPARAM)buf, NULL, NULL );
	printf( "Selected Frame Number: %d\n", (*ppRefItm)->lMyID );

	// Show selectable frame number
	if ( pRefSrc->ulChildCount > 1 ) {
		printf( "Input Frame Number (1 - %d)\n", pRefSrc->ulChildCount);
		printf( ">" );
		scanf( "%s", buf );
		wSel = atoi( buf );
		if ( wSel > 0 && wSel <= pRefSrc->ulChildCount )
			*ppRefItm = GetRefChildPtr_ID( pRefSrc, wSel );
	} else
		printf( "You can not select frame number.\n" );

	return (*ppRefItm)->lMyID;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void ShowScanCondition(LPRefObj pRefDat) 
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
//	LPNkMAIDCapInfo pCapInfo;
	NkMAIDRange	stRange;
	NkMAIDEnum	stEnum;
	NkMAIDRect	stRect;
	BYTE	bFlag;
	double	lfValue;
	char	sColorspace[16];

	// show film-type wheter positive or negative
	if ( CheckCapabilityOperation( pRefDat, kNkMAIDCapability_Negative, kNkMAIDCapOperation_Get ) ) {
		Command_CapGet( pDataObject, kNkMAIDCapability_Negative, kNkMAIDDataType_BooleanPtr, (NKPARAM)&bFlag, NULL, NULL );
		bFlag ? printf( "FilmType: Negative\n" ) : printf( "FilmType: Positive\n" );
	}

	// show color space (RGB, CMYK, ...etc.)
	if ( CheckCapabilityOperation( pRefDat, kNkMAIDCapability_ColorSpace, kNkMAIDCapOperation_Get ) ) {
		if ( GetCapInfo( pRefDat, kNkMAIDCapability_ColorSpace)->ulType == kNkMAIDCapType_Enum ){
			Command_CapGet( pDataObject, kNkMAIDCapability_ColorSpace, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
			if ( stEnum.ulType == kNkMAIDDataType_Integer && stEnum.wPhysicalBytes == 4 ) {
				// allocate memory for array data
				stEnum.pData = malloc( stEnum.ulElements * stEnum.wPhysicalBytes );
				// get array data
				Command_CapGetArray( pDataObject, kNkMAIDCapability_ColorSpace, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
				GetNkColorSpaceString ( sColorspace, ((SLONG*)stEnum.pData)[stEnum.ulValue] );
				printf( "ColorSpace: %s\n", sColorspace );
				if ( stEnum.pData != NULL )
					free( stEnum.pData );
			}
		}
	}

	// show scanning resolution
	if ( CheckCapabilityOperation( pRefDat, kNkMAIDCapability_Resolution, kNkMAIDCapOperation_Get ) ) {
		if (GetCapInfo( pRefDat, kNkMAIDCapability_Resolution)->ulType == kNkMAIDCapType_Range){
			Command_CapGet( pDataObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_RangePtr, (NKPARAM)&stRange, NULL, NULL );
			if ( stRange.ulSteps == 0 ) {
				// resolution is set to 'lfValue' directly
				lfValue = stRange.lfValue;
			} else {
				// resolution is calculated from 'ulValueIndex'
				lfValue = stRange.lfLower + stRange.ulValueIndex * (stRange.lfUpper - stRange.lfLower) / (stRange.ulSteps - 1);
			}
			printf( "Resolution: %6.1f\n", lfValue );
		}else if ( GetCapInfo( pRefDat, kNkMAIDCapability_Resolution)->ulType == kNkMAIDCapType_Enum ){
			Command_CapGet( pDataObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
			if ( stEnum.ulType == kNkMAIDArrayType_Float ) {
				// allocate memory for array data
				stEnum.pData = malloc( stEnum.ulElements * stEnum.wPhysicalBytes );
				// get array data
				Command_CapGetArray( pDataObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
				printf( "Resolution: %s\n", ((DOUB_P*)stEnum.pData)[stEnum.ulValue] );
				if ( stEnum.pData != NULL )
					free( stEnum.pData );
			}
		}
	}

	// show scan rectangle
	if ( CheckCapabilityOperation( pRefDat, kNkMAIDCapability_Coords, kNkMAIDCapOperation_Get ) ) {
			Command_CapGet( pDataObject, kNkMAIDCapability_Coords, kNkMAIDDataType_RectPtr, (NKPARAM)&stRect, NULL, NULL );
			printf( "Rect: left = %d    top = %d    width = %d    height = %d\n", stRect.x, stRect.y, stRect.w, stRect.h );
	}

	// show bits depth
	if ( CheckCapabilityOperation( pRefDat, kNkMAIDCapability_Bits, kNkMAIDCapOperation_Get ) ) {
		Command_CapGet( pDataObject, kNkMAIDCapability_Bits, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
		if ( stEnum.ulType == kNkMAIDDataType_Integer && stEnum.wPhysicalBytes == 4 ) {
			// allocate memory for array data
			stEnum.pData = malloc( stEnum.ulElements * stEnum.wPhysicalBytes );
			// get array data
			Command_CapGetArray( pDataObject, kNkMAIDCapability_Bits, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
			printf( "Scan Bit Depth: %d\n", ((SLONG*)stEnum.pData)[stEnum.ulValue] );
			if ( stEnum.pData != NULL )
				free( stEnum.pData );
		}
	}
}
//------------------------------------------------------------------------------------------------------------------------------------
// Set Capability_Negative. If original is negative film, this capability is set true.
void SetNegative(LPRefObj pRefDat)
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
	BYTE	bFlag;
	char	buf[256];
	UWORD	wSel;

	// show film-type wheter positive or negative
	if ( CheckCapabilityOperation( pRefDat, kNkMAIDCapability_Negative, kNkMAIDCapOperation_Get ) &&
			CheckCapabilityOperation( pRefDat, kNkMAIDCapability_Negative, kNkMAIDCapOperation_Set ) ) {
		Command_CapGet( pDataObject, kNkMAIDCapability_Negative, kNkMAIDDataType_BooleanPtr, (NKPARAM)&bFlag, NULL, NULL );
		bFlag ? printf( "FilmType: Negative\n" ) : printf( "FilmType: Positive\n" );

		printf( "1. Positive    2. Negative\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );
		if ( (wSel == 1) || (wSel == 2) ) {
			bFlag = (wSel == 2) ? true : false;
			Command_CapSet( pDataObject, kNkMAIDCapability_Negative, kNkMAIDDataType_Boolean, (NKPARAM)bFlag, NULL, NULL );
		}
	}
}
//------------------------------------------------------------------------------------------------------------------------------------
//
char* GetNkColorSpaceString( char *psColorspace, SLONG ulValue )
{
	switch ( ulValue ) {
		case kNkMAIDColorSpace_LineArt:
			strcpy( psColorspace, "LineArt" ); 
			break;
		case kNkMAIDColorSpace_Grey:
			strcpy( psColorspace, "Grey" ); 
			break;
		case kNkMAIDColorSpace_RGB:
			strcpy( psColorspace, "RGB" ); 
			break;
		case kNkMAIDColorSpace_sRGB:
			strcpy( psColorspace, "sRGB" ); 
			break;
		case kNkMAIDColorSpace_CMYK:
			strcpy( psColorspace, "CMYK" ); 
			break;
		case kNkMAIDColorSpace_Lab:
			strcpy( psColorspace, "Lab" ); 
			break;
		case kNkMAIDColorSpace_LCH:
			strcpy( psColorspace, "LCH" ); 
			break;
		default:
			strcpy( psColorspace, "Unknown" ); 
	}
	return psColorspace;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void SetNkColorSpace(LPRefObj pRefDat)
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
	LPNkMAIDCapInfo pCapInfo = GetCapInfo( pRefDat, kNkMAIDCapability_ColorSpace );
	NkMAIDEnum	stEnum;
	char	sColorspace[16], buf[256];
	UWORD	wSel;
	ULONG i;

	// show color space (RGB, CMYK, ...etc.)
	if ( CheckCapabilityOperation( pRefDat, kNkMAIDCapability_ColorSpace, kNkMAIDCapOperation_Get ) &&
			CheckCapabilityOperation( pRefDat, kNkMAIDCapability_ColorSpace, kNkMAIDCapOperation_Set ) ) {
		if ( pCapInfo->ulType == kNkMAIDCapType_Enum ){
			Command_CapGet( pDataObject, kNkMAIDCapability_ColorSpace, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
			if ( stEnum.ulType == kNkMAIDDataType_Integer && stEnum.wPhysicalBytes == 4 ) {
				// allocate memory for array data
				stEnum.pData = malloc( stEnum.ulElements * stEnum.wPhysicalBytes );
				if ( stEnum.pData == NULL )
					return;
				// get array data
				Command_CapGetArray( pDataObject, kNkMAIDCapability_ColorSpace, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
				GetNkColorSpaceString( sColorspace, ((SLONG*)stEnum.pData)[stEnum.ulValue] );
				printf( "%s: %s\n", pCapInfo->szDescription, sColorspace );
				for ( i = 0; i < stEnum.ulElements; i++ )
					printf( "%2d. %s\n", i + 1, GetNkColorSpaceString( sColorspace, ((SLONG*)stEnum.pData)[i]) );
				printf( "\n>" );
				scanf( "%s", buf );
				wSel = atoi( buf );
				if ( wSel > 0 && wSel <= stEnum.ulElements ) {
					stEnum.ulValue = wSel - 1;
					Command_CapSet( pDataObject, kNkMAIDCapability_ColorSpace, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
				}
				free( stEnum.pData );
			}
		}
	}
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void SetResolution(LPRefObj pRefDat)
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
	LPNkMAIDCapInfo pCapInfo = GetCapInfo( pRefDat, kNkMAIDCapability_Resolution );
	NkMAIDRange	stRange;
	NkMAIDEnum	stEnum;
	double	lfValue;
	char	buf[256];
	ULONG	i;

	if ( CheckCapabilityOperation(pRefDat, kNkMAIDCapability_Resolution, kNkMAIDCapOperation_Get) &&
			CheckCapabilityOperation(pRefDat, kNkMAIDCapability_Resolution, kNkMAIDCapOperation_Set) ) {
		if ( pCapInfo->ulType == kNkMAIDCapType_Range ){
			Command_CapGet( pDataObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_RangePtr, (NKPARAM)&stRange, NULL, NULL );
			if ( stRange.ulSteps == 0 ) {
				// resolution is set to 'lfValue' directly
				printf( "%s: %f  (Max: %f  Min: %f)\n", pCapInfo->szDescription, stRange.lfValue, stRange.lfUpper, stRange.lfLower );
				printf( "New value > " );
				scanf( "%s", buf );
				stRange.lfValue = atof( buf );
			} else {
				// resolution is calculated from 'ulValueIndex'
				lfValue = stRange.lfLower + stRange.ulValueIndex * (stRange.lfUpper - stRange.lfLower) / (stRange.ulSteps - 1);
				printf( "%s: %f  (Max: %f  Min: %f)\n", pCapInfo->szDescription, lfValue, stRange.lfUpper, stRange.lfLower );
				printf( "New value > " );
				scanf( "%s", buf );
				lfValue = atof( buf );
				stRange.ulValueIndex = (ULONG)((lfValue - stRange.lfLower) * (stRange.ulSteps - 1) / (stRange.lfUpper - stRange.lfLower));
			}
			Command_CapSet( pDataObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_RangePtr, (NKPARAM)&stRange, NULL, NULL );
		} else if ( pCapInfo->ulType == kNkMAIDCapType_Enum ){
			Command_CapGet( pDataObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
			if ( stEnum.ulType == kNkMAIDArrayType_Float ) {
				// allocate memory for array data
				stEnum.pData = malloc( stEnum.ulElements * stEnum.wPhysicalBytes );
				if ( stEnum.pData == NULL )
					return;
				// get array data
				Command_CapGetArray( pDataObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
				printf( "%s: %f\n", pCapInfo->szDescription, ((DOUB_P*)stEnum.pData)[stEnum.ulValue] );
				for ( i = 0; i < stEnum.ulElements; i++ )
					printf( "%d. %f\n", i + 1, ((DOUB_P*)stEnum.pData)[i] );
				printf( "Select Resolution ( 1 - %d ) > ", stEnum.ulElements );
				scanf( "%s", buf );
				stEnum.ulValue = atoi( buf ) - 1;
				Command_CapSet( pDataObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
				free( stEnum.pData );
			}
		}
	}
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void SetRectangle(LPRefObj pRefDat)
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
	LPNkMAIDCapInfo pCapInfo = GetCapInfo( pRefDat, kNkMAIDCapability_Coords );
	NkMAIDRect	stRect;
	char	buf[256];

	// show scan rectangle
	if ( CheckCapabilityOperation( pRefDat, kNkMAIDCapability_Coords, kNkMAIDCapOperation_Get ) &&
			CheckCapabilityOperation( pRefDat, kNkMAIDCapability_Coords, kNkMAIDCapOperation_Set ) ) {
		Command_CapGet( pDataObject, kNkMAIDCapability_Coords, kNkMAIDDataType_RectPtr, (NKPARAM)&stRect, NULL, NULL );
		printf( "%s: left = %d    top = %d    width = %d    height = %d\n", pCapInfo->szDescription, stRect.x, stRect.y, stRect.w, stRect.h );
		printf("left = ");	scanf( "%s", buf );	stRect.x = atoi( buf );	
		printf("top = ");		scanf( "%s", buf );	stRect.y = atoi( buf );
		printf("width = ");	scanf( "%s", buf );	stRect.w = atoi( buf );
		printf("height = ");	scanf( "%s", buf );	stRect.h = atoi( buf );
		Command_CapSet( pDataObject, kNkMAIDCapability_Coords, kNkMAIDDataType_RectPtr, (NKPARAM)&stRect, NULL, NULL );
	}

}
//------------------------------------------------------------------------------------------------------------------------------------
// make look up table and send it to module.
void SetGamma( LPRefObj pRefDat )
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
	NkMAIDArray stArray;
	double	lfGamma, dfMaxvalue;
	ULONG	i, ulLUTDimSize, ulPlaneCount;
	char	buf[256];

	printf( "Gamma >");
	scanf( "%s", buf );
	lfGamma = atof( buf );

	Command_CapGet(pDataObject, kNkMAIDCapability_Lut, kNkMAIDDataType_ArrayPtr, (NKPARAM)&stArray, NULL, NULL);
	stArray.pData = malloc(stArray.ulElements * stArray.wPhysicalBytes);
	if( stArray.pData == NULL )
		return;

	ulLUTDimSize = stArray.ulDimSize1;
	ulPlaneCount = stArray.ulDimSize2;
	dfMaxvalue = (double)(ulLUTDimSize - 1);

	// Make look up table
	if(stArray.wPhysicalBytes == 1) {
		for( i = 0; i < ulLUTDimSize; i++)
			((UCHAR*)stArray.pData)[i] = (UCHAR)( pow( ((double)i / dfMaxvalue), 1.0 / lfGamma ) * dfMaxvalue + 0.5 ); 
	} else if(stArray.wPhysicalBytes == 2) {
		for( i = 0; i < ulLUTDimSize; i++)
			((UWORD*)stArray.pData)[i] = (UWORD)( pow( ((double)i / dfMaxvalue), 1.0 / lfGamma ) * dfMaxvalue + 0.5 ); 
	} else {
		free(stArray.pData);
		return;
	}

	for( i = 1; i < ulPlaneCount; i++)
		memcpy( (LPVOID)((ULONG)stArray.pData + i * ulLUTDimSize * stArray.wPhysicalBytes), stArray.pData, ulLUTDimSize * stArray.wPhysicalBytes );

	// Send look up table
	Command_CapSet(pDataObject, kNkMAIDCapability_Lut, kNkMAIDDataType_ArrayPtr, (NKPARAM)&stArray, NULL, NULL);

	free(stArray.pData);
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void SetBitDepth(LPRefObj pRefDat)
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
	LPNkMAIDCapInfo pCapInfo = GetCapInfo( pRefDat, kNkMAIDCapability_Bits );
	NkMAIDEnum	stEnum;
	char	buf[256];
	UWORD	wSel;
	ULONG i;

	// show bits depth
	if ( CheckCapabilityOperation( pRefDat, kNkMAIDCapability_Bits, kNkMAIDCapOperation_Get ) &&
			CheckCapabilityOperation( pRefDat, kNkMAIDCapability_Bits, kNkMAIDCapOperation_Set ) ) {
		Command_CapGet( pDataObject, kNkMAIDCapability_Bits, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
		if ( stEnum.ulType == kNkMAIDDataType_Integer && stEnum.wPhysicalBytes == 4 ) {
			// allocate memory for array data
			stEnum.pData = malloc( stEnum.ulElements * stEnum.wPhysicalBytes );
			if ( stEnum.pData == NULL )
				return;
			// get array data
			Command_CapGetArray( pDataObject, kNkMAIDCapability_Bits, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
			printf( "%s: %d\n", pCapInfo->szDescription, ((SLONG*)stEnum.pData)[stEnum.ulValue] );
			for ( i = 0; i < stEnum.ulElements; i++ )
				printf( "%2d. %2d\n", i + 1, ((SLONG*)stEnum.pData)[i] );
			printf( "\n>" );
			scanf( "%s", buf );
			wSel = atoi( buf );
			if (wSel > 0 && wSel <= stEnum.ulElements ) {
				stEnum.ulValue = wSel - 1;
				Command_CapSet( pDataObject, kNkMAIDCapability_Bits, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
			}
			free( stEnum.pData );
		}
	}
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void SetScanCondition(LPRefObj pRefDat) 
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
	char	buf[256];
	ULONG	ulID, ulOffset = 6;
	ULONG	ulNumOfSelector;
	ULONG	*pulSpecialCapArray, ulNumOfSpecialCap = 0L;
	UWORD	wSel;

	pulSpecialCapArray = malloc( CountSpecialCap(pRefDat) * sizeof(ULONG) );
	if ( pulSpecialCapArray == NULL )
		return;

	do {
		// Wait for selection by user
		printf( "\nSelect Capability to be set\n" );
		printf( " 1. Negative/Positive        2. ColorSpace                3. Resolution\n" );
		printf( " 4. Rectangle                5. Gamma                     6. BitDepth\n" );
		ulNumOfSelector = ShowSpecialCapabilityMenu( pRefDat, pulSpecialCapArray, ulOffset );
		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );

		switch( wSel )
		{
			case 1:// Negative setting
				SetNegative( pRefDat );
				break;
			case 2:// ColorSpace
				SetNkColorSpace( pRefDat );
				break;
			case 3:// Resolution
				SetResolution( pRefDat );
				break;
			case 4:// Rectangle
				SetRectangle( pRefDat );
				break;
			case 5:// Gamma
				SetGamma( pRefDat );
				break;
			case 6:// BitDepth
				SetBitDepth( pRefDat );
				break;
			default:
				if (wSel > 0 && wSel <= ulNumOfSelector ) {
					ulID = pulSpecialCapArray[wSel - ulOffset - 1];
					SetSpecialCapability( pRefDat, ulID );
				}
		}
	} while( wSel != 0 );

	free( pulSpecialCapArray );
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void IssuePrescan(LPRefObj pRefDat) 
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
	ULONG	ulCount = 0L;
	LPRefCompletionProc pRefCompletion;
	pRefCompletion = malloc( sizeof(RefCompletionProc) );
	pRefCompletion->pulCount = &ulCount;
	pRefCompletion->pRef = NULL;

	// Start Prescan
	Command_CapStart( pDataObject, kNkMAIDCapability_Prescan, (LPNKFUNC)CompletionProc, (NKREF)pRefCompletion);
	// Wait for end of prescan and issue Command_Async.
	IdleLoop( pDataObject, &ulCount, 1 );
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void IssueAutofocus(LPRefObj pRefDat)
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
	LPNkMAIDCapInfo pCapInfo;
	ULONG	ulCount = 0L;
	LPRefCompletionProc pRefCompletion;
	pRefCompletion = malloc( sizeof(RefCompletionProc) );
	pRefCompletion->pulCount = &ulCount;
	pRefCompletion->pRef = NULL;

	// Confirm whether Capability_AutoFocus is supported or not.
	pCapInfo =	GetCapInfo(pRefDat, kNkMAIDCapability_AutoFocus);
	if( pCapInfo == NULL )
		return;

	// Start Autofocus
	Command_CapStart( pDataObject, kNkMAIDCapability_AutoFocus, (LPNKFUNC)CompletionProc, (NKREF)pRefCompletion );
	// Wait for end of Autofocus and issue Command_Async.
	IdleLoop( pDataObject, &ulCount, 1 );
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void IssueEject(LPRefObj pRefDat)
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
	LPNkMAIDCapInfo pCapInfo;
	ULONG	ulCount = 0L;
	LPRefCompletionProc pRefCompletion;
	pRefCompletion = malloc( sizeof(RefCompletionProc) );
	pRefCompletion->pulCount = &ulCount;
	pRefCompletion->pRef = NULL;

	// Confirm whether Capability_AutoFocus is supported or not.
	pCapInfo =	GetCapInfo(pRefDat, kNkMAIDCapability_Eject);
	if( pCapInfo == NULL )
		return;
	// eject start
	Command_CapStart( pDataObject, kNkMAIDCapability_Eject, (LPNKFUNC)CompletionProc, (NKREF)pRefCompletion );
	// wait for end of eject
	IdleLoop( pDataObject, &ulCount, 1 );
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void IssueScan( LPRefObj pRefDat )
{
	NkMAIDCallback	stProc;
	LPRefDeliver	pRefDeliver;
	LPRefCompletionProc	pRefCompletion;
	ULONG ulCount = 0L;

	// set reference from DataProc
	pRefDeliver = malloc( sizeof(RefDeliver) );
	pRefDeliver->pBuffer = NULL;
	pRefDeliver->ulOffset = 0L;
	pRefDeliver->ulTotalLines = 0L;
	pRefDeliver->lID = ((LPRefObj)pRefDat->pRefParent)->lMyID;
	// set reference from CompletionProc
	pRefCompletion = malloc( sizeof(RefCompletionProc) );
	pRefCompletion->pulCount = &ulCount;
	pRefCompletion->pRef = pRefDeliver;
	// set reference from DataProc
	stProc.pProc = (LPNKFUNC)DataProc;
	stProc.refProc = (NKREF)pRefDeliver;

	// set DataProc as data delivery callback function
	Command_CapSet( pRefDat->pObject, kNkMAIDCapability_DataProc, kNkMAIDDataType_CallbackPtr, (NKPARAM)&stProc, NULL, NULL );
	// scanning start
	Command_CapStart( pRefDat->pObject, kNkMAIDCapability_Acquire, (LPNKFUNC)CompletionProc, (NKREF)pRefCompletion );
	IdleLoop( pRefDat->pObject, &ulCount, 1 );
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void IssueThumbnail( LPRefObj pRefSrc )
{
	LPRefObj pRefItm, pRefDat;
	LPNkMAIDCapInfo	pCapInfo;
	NkMAIDRange	stRange;
	NkMAIDEnum	stEnum;
	NkMAIDCallback	stProc;
	LPRefDeliver	pRefDeliver;
	LPRefCompletionProc	pRefCompletion;
	ULONG	ulNumOfItem = pRefSrc->ulChildCount;
	ULONG ulValue;
	DOUB_P	lfLower;
	ULONG	ulCount = 0L;
	ULONG i, j;

	// return, if acquiring thumbnail images is not supported. 
	if ( ( pRefDat = GetRefChildPtr_ID( GetRefChildPtr_Index( pRefSrc, 0 ), kNkMAIDDataObjType_Thumbnail ) ) == NULL )
		return;
	pCapInfo = GetCapInfo( pRefDat, kNkMAIDCapability_Resolution );

	// In this sample, we set resolution lower value. (We can set any value between lower and upper.)
	if ( pCapInfo->ulType == kNkMAIDCapType_Range ) {
		Command_CapGet( pRefDat->pObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_RangePtr, (NKPARAM)&stRange, NULL, NULL );
		if ( stRange.ulSteps )
			stRange.ulValueIndex = 0;
		else
			stRange.lfValue = stRange.lfLower;
	} else if ( pCapInfo->ulType == kNkMAIDCapType_Enum ) {
		Command_CapGet( pRefDat->pObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
		if ( stEnum.ulType == kNkMAIDArrayType_Float ) {
			// allocate memory for array data
			stEnum.pData = malloc( stEnum.ulElements * stEnum.wPhysicalBytes );
			if ( stEnum.pData == NULL )
				return;
			// get array data
			Command_CapGetArray( pRefDat->pObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
			ulValue = 0;
			lfLower = ((DOUB_P*)stEnum.pData)[0];
			for ( i = 1; i < stEnum.ulElements; i++ ) {
				if ( lfLower > ((DOUB_P*)stEnum.pData)[i] ) {
					ulValue = i;
					lfLower = ((DOUB_P*)stEnum.pData)[i];
				}
			}
			stEnum.ulValue = ulValue;
			free( stEnum.pData );
		} else
			return;
	} else
		return;

	// set NkMAIDCallback structure for DataProc
	stProc.pProc = (LPNKFUNC)DataProc;

	// we always acquire all thumbnail images.
	for ( i = 0; i < ulNumOfItem; i++ ) {
		pRefItm = GetRefChildPtr_Index( pRefSrc, i );
		pRefDat = GetRefChildPtr_ID( pRefItm, kNkMAIDDataObjType_Thumbnail );

		if ( pCapInfo->ulType == kNkMAIDCapType_Range )
			Command_CapSet( pRefDat->pObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_RangePtr, (NKPARAM)&stRange, NULL, NULL );
		else
			Command_CapSet( pRefDat->pObject, kNkMAIDCapability_Resolution, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
		
		// set RefDeliver structure refered from DataProc
		pRefDeliver = malloc( sizeof(RefDeliver) );
			// this memory block will be free in CompletionProc.
		pRefDeliver->pBuffer = NULL;
		pRefDeliver->ulOffset = 0L;
		pRefDeliver->ulTotalLines = 0L;
		pRefDeliver->lID = pRefItm->lMyID;

		// set the data delivery callback function
		stProc.refProc = (NKREF)pRefDeliver;
		Command_CapSet( pRefDat->pObject, kNkMAIDCapability_DataProc, kNkMAIDDataType_CallbackPtr, (NKPARAM)&stProc, NULL, NULL );

		pRefCompletion = malloc( sizeof(RefCompletionProc) );
			// This memory block will be free in CompletionProc.

		// Set RefCompletion structure refered from CompletionProc.
		pRefCompletion->pulCount = &ulCount;
		pRefCompletion->pRef = pRefDeliver;

		// Starting Acquire Thumbnail
		Command_CapStart( pRefDat->pObject, kNkMAIDCapability_Acquire, (LPNKFUNC)CompletionProc, (NKREF)pRefCompletion );

		// Send Async command to all DataObjects that have received start command.
		for ( j = 0; j <= i; j++ )
			Command_Async( GetRefChildPtr_ID(GetRefChildPtr_Index(pRefSrc, j ), kNkMAIDDataObjType_Thumbnail)->pObject );
	}

	// Send Async command to all DataObjects, untill all scanning complete.
	while ( ulCount < ulNumOfItem ) {
		for ( j = 0; j < ulNumOfItem; j++ )
			Command_Async( GetRefChildPtr_ID(GetRefChildPtr_Index( pRefSrc, j), kNkMAIDDataObjType_Thumbnail )->pObject );
	}
}

//------------------------------------------------------------------------------------------------------------------------------------
//
ULONG ShowSpecialCapabilityMenu( LPRefObj pRefDat, ULONG *pulSpecialCapArray, ULONG ulNumOfSelector )
{
	LPNkMAIDObject pDataObject = pRefDat->pObject;
	LPNkMAIDCapInfo pCapInfo;
	NkMAIDEnum stEnum;
	NkMAIDArray stArray;
	ULONG ulID, i;
	ULONG	ulNumOfSpecialCap = 0L;

	stEnum.pData = NULL;
	stArray.pData = NULL;

	for ( i = 0; i < pRefDat->ulCapCount; i++ ){
		pCapInfo = &((NkMAIDCapInfo*)pRefDat->pCapArray)[i];
		ulID = pCapInfo->ulID;
		if( (pCapInfo->ulVisibility & kNkMAIDCapVisibility_Vendor) &&
			!(pCapInfo->ulVisibility & kNkMAIDCapVisibility_GroupMember) ) {
			switch(pCapInfo->ulType) {
				case kNkMAIDCapType_Array:
					if ( pCapInfo->ulVisibility & kNkMAIDCapVisibility_Group ) {
						pulSpecialCapArray[ulNumOfSpecialCap++] = ulID;
						printf( "%2d. %s\n", ++ulNumOfSelector, pCapInfo->szDescription );
					}
					break;
				case kNkMAIDCapType_Enum:
				case kNkMAIDCapType_Boolean:
					if ( !(pCapInfo->ulVisibility & kNkMAIDCapVisibility_Hidden) ) {
						pulSpecialCapArray[ulNumOfSpecialCap++] = ulID;
						printf( "%2d. %s\n", ++ulNumOfSelector, pCapInfo->szDescription );
					}
					break;
				case kNkMAIDCapType_Unsigned:
					break;
				case kNkMAIDCapType_Range:
					break;
				case kNkMAIDCapType_Generic:
					break;
				default:
					;
			}
		}
	}
	return ulNumOfSelector;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
void SetSpecialCapability( LPRefObj pRefDat, ULONG ulID )
{
	LPNkMAIDObject	pDataObject = pRefDat->pObject;
	LPNkMAIDCapInfo	pCapInfo = GetCapInfo( pRefDat, ulID ), pTmpCapInfo = NULL;
	NkMAIDEnum	stEnum;
	NkMAIDArray	stArray;
	NkMAIDRange	stRange;
	BYTE	bFlag;
	double	lfValue;
	ULONG	i;
	char	buf[256];
	UWORD	wSel;
	LPRefCompletionProc pRefCompletion;
	ULONG	ulCount = 0L;

	stEnum.pData = NULL;
	stArray.pData = NULL;

	// if selected capability is grouping one, select member from that group
	if( (pCapInfo->ulVisibility & kNkMAIDCapVisibility_Group) &&
			CheckCapabilityOperation( pRefDat, ulID, kNkMAIDCapOperation_Get ) ) {
		Command_CapGet( pDataObject, ulID, kNkMAIDDataType_ArrayPtr, (NKPARAM)&stArray, NULL, NULL );
		stArray.pData = malloc( stArray.ulElements * stArray.wPhysicalBytes );
		if ( stArray.pData == NULL )
			return;
		// Get array of capabilities belong to the group
		Command_CapGetArray( pDataObject, ulID, kNkMAIDDataType_ArrayPtr, (NKPARAM)&stArray, NULL, NULL );
		for ( i = 0; i < stArray.ulElements; i++ ) {
			pTmpCapInfo = GetCapInfo( pRefDat, ((ULONG*)stArray.pData)[i] );
			printf( "%2d. %s\n", i + 1, pTmpCapInfo->szDescription );
		}

		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );
		if (wSel <= 0 || wSel > stArray.ulElements ) {
			free( stArray.pData );
			return;
		}
		// set ID of the selected capability to 'ulID'
		ulID = ((ULONG*)stArray.pData)[wSel-1];
		// get pointer to CapInfo structure
		pCapInfo = GetCapInfo( pRefDat, ulID );
		free( stArray.pData );
		stArray.pData = NULL;
	}

	switch(pCapInfo->ulType) {
		case kNkMAIDCapType_Enum:
			if ( CheckCapabilityOperation( pRefDat, ulID, kNkMAIDCapOperation_Get ) &&
					CheckCapabilityOperation( pRefDat, ulID, kNkMAIDCapOperation_Set ) ) {
				// after Command_CapGet, variables of NkMAIDEnum structure have been set.
				Command_CapGet( pDataObject, ulID, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
				// allocate memory for array data.
				stEnum.pData = malloc( stEnum.ulElements * stEnum.wPhysicalBytes );
				if ( stEnum.pData == NULL )
					return;
				// get array data.
				Command_CapGetArray( pDataObject, ulID, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
				if ( stEnum.ulType == kNkMAIDArrayType_String ) {
					printf( "%s: %s\n", pCapInfo->szDescription, ((NkMAIDString*)stEnum.pData)[stEnum.ulValue].str );
					for ( i = 0; i < stEnum.ulElements; i++ )
						printf( "%2d. %s\n", i + 1, ((NkMAIDString*)stEnum.pData)[i].str );
				} else if ( stEnum.ulType == kNkMAIDArrayType_Integer && stEnum.wPhysicalBytes == 4 ) {
					printf( "%s: %d\n", pCapInfo->szDescription, ((ULONG*)stEnum.pData)[stEnum.ulValue] );
					for ( i = 0; i < stEnum.ulElements; i++ )
						printf( "%2d. %d\n", i + 1, ((ULONG*)stEnum.pData)[i] );
				}
				printf( "\n>" );
				scanf( "%s", buf );
				wSel = atoi( buf );
				if ( wSel > 0 && wSel <= stEnum.ulElements ) {
					stEnum.ulValue = wSel - 1;
					Command_CapSet( pDataObject, ulID, kNkMAIDDataType_EnumPtr, (NKPARAM)&stEnum, NULL, NULL );
				}
				free( stEnum.pData );
			}
			break;
		case kNkMAIDCapType_Boolean:
			if ( CheckCapabilityOperation( pRefDat, ulID, kNkMAIDCapOperation_Get ) &&
					CheckCapabilityOperation( pRefDat, ulID, kNkMAIDCapOperation_Set ) ) {
				Command_CapGet( pDataObject, ulID, kNkMAIDDataType_BooleanPtr, (NKPARAM)&bFlag, NULL, NULL );
				bFlag ? strcpy( buf, "TRUE" ) : strcpy( buf, "FALSE" );
				printf( "%s: %s\n", pCapInfo->szDescription, buf );
				printf( "1. TRUE    2. FALSE\n>" );
				scanf( "%s", buf );
				wSel = atoi( buf );
				if ( (wSel == 1) || (wSel == 2) ) {
					bFlag = !(wSel - 1);
					Command_CapSet( pDataObject, ulID, kNkMAIDDataType_BooleanPtr, (NKPARAM)&bFlag, NULL, NULL );
				}
			}
			break;
		case kNkMAIDCapType_Range:
			if ( CheckCapabilityOperation( pRefDat, ulID, kNkMAIDCapOperation_Get ) &&
					CheckCapabilityOperation( pRefDat, ulID, kNkMAIDCapOperation_Set ) ) {
				Command_CapGet( pDataObject, ulID, kNkMAIDDataType_RangePtr, (NKPARAM)&stRange, NULL, NULL );
				if ( stRange.ulSteps == 0 ) {
					// lfValue is set directly
					printf( "%s: %f  (Max: %f  Min: %f)\n", pCapInfo->szDescription, stRange.lfValue, stRange.lfUpper, stRange.lfLower );
					printf( "New value >" );
					scanf( "%s", buf );
					stRange.lfValue = atof( buf );
				} else {
					// lfValue is calculated from ulValueIndex
					lfValue = stRange.lfLower + stRange.ulValueIndex * (stRange.lfUpper - stRange.lfLower) / (stRange.ulSteps - 1);
					printf( "%s: %f  (Max: %f  Min: %f)\n", pCapInfo->szDescription, lfValue, stRange.lfUpper, stRange.lfLower );
					printf( "New value >" );
					scanf( "%s", buf );
					lfValue = atof( buf );
					stRange.ulValueIndex = (ULONG)((lfValue - stRange.lfLower) * (stRange.ulSteps - 1) / (stRange.lfUpper - stRange.lfLower));
				}
				Command_CapSet( pDataObject, ulID, kNkMAIDDataType_RangePtr, (NKPARAM)&stRange, NULL, NULL );
			}
			break;
		case kNkMAIDCapType_Process:
			pRefCompletion = malloc( sizeof(RefCompletionProc) );
			pRefCompletion->pulCount = &ulCount;
			pRefCompletion->pRef = NULL;
			Command_CapStart( pDataObject, ulID, (LPNKFUNC)CompletionProc, (NKREF)pRefCompletion );
			IdleLoop( pDataObject, &ulCount, 1 );
			break;
		default:
			;
	}
}
//------------------------------------------------------------------------------------------------------------------------------------
// get pointer to CapInfo, the capability ID of that is 'ulID'
LPNkMAIDCapInfo GetCapInfo(LPRefObj pRef, ULONG ulID)
{
	LPNkMAIDCapInfo pCapInfo;
	ULONG i;

	if (pRef == NULL)
		return NULL;
	for ( i = 0; i < pRef->ulCapCount; i++ ){
		pCapInfo = (LPNkMAIDCapInfo)( (ULONG)pRef->pCapArray + i * sizeof(NkMAIDCapInfo) );
		if ( pCapInfo->ulID == ulID )
			break;
	}
	if ( i < pRef->ulCapCount )
		return pCapInfo;
	else
		return NULL;
}
//------------------------------------------------------------------------------------------------------------------------------------
// get number of special capabilities
ULONG CountSpecialCap(LPRefObj pRef)
{
	LPNkMAIDCapInfo pCapInfo;
	ULONG i, ulCount = 0;

	for(i = 0; i < pRef->ulCapCount; i++)
	{
		pCapInfo = (LPNkMAIDCapInfo)( (ULONG)pRef->pCapArray + i * sizeof(NkMAIDCapInfo) );
		if( pCapInfo->ulID >= kNkMAIDCapability_VendorBase )
			ulCount++;
	}

	return ulCount;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL CheckCapabilityOperation(LPRefObj pRef, ULONG ulID, ULONG ulOperations)
{
	SLONG nResult;
	LPNkMAIDCapInfo pCapInfo = GetCapInfo(pRef, ulID);

	if(pCapInfo != NULL){
		if(pCapInfo->ulOperations & ulOperations){
			nResult = kNkMAIDResult_NoError;
		}else{
			nResult = kNkMAIDResult_NotSupported;
		}
	}else{
		nResult = kNkMAIDResult_NotSupported;
	}

	return (nResult == kNkMAIDResult_NoError);
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL AddChild( LPRefObj pRefParent, SLONG lIDChild )
{
	SLONG lResult;
	ULONG ulCount = pRefParent->ulChildCount;
	LPVOID pNewMemblock = realloc( pRefParent->pRefChildArray, (ulCount + 1) * sizeof(LPRefObj) );
	LPRefObj pRefChild = (LPRefObj)malloc( sizeof(RefObj) );
	NkMAIDCallback	stProc;

	if(pNewMemblock == NULL || pRefChild == NULL) {
		puts( "There is not enough memory" );
		return FALSE;
	}
	pRefParent->pRefChildArray = pNewMemblock;
	((LPRefObj*)pRefParent->pRefChildArray)[ulCount] = pRefChild;
	InitRefObj(pRefChild);
	pRefChild->lMyID = lIDChild;
	pRefChild->pRefParent = pRefParent;
	pRefChild->pObject = (LPNkMAIDObject)malloc(sizeof(NkMAIDObject));
	if(pRefChild->pObject == NULL){
		puts( "There is not enough memory" );
		pRefParent->pRefChildArray = realloc( pRefParent->pRefChildArray, ulCount * sizeof(LPRefObj) );
		return FALSE;
	}

	pRefChild->pObject->refClient = (NKREF)pRefChild;
	lResult = Open_Object( pRefParent->pObject, pRefChild->pObject, lIDChild );
	if(lResult == TRUE)
		pRefParent->ulChildCount ++;
	else {
		puts( "Source object is not opened" );
		pRefParent->pRefChildArray = realloc( pRefParent->pRefChildArray, ulCount * sizeof(LPRefObj) );
		free(pRefChild->pObject);
		free(pRefChild);
		return FALSE;
	}

	lResult = EnumCapabilities( pRefChild->pObject, &(pRefChild->ulCapCount), &(pRefChild->pCapArray), NULL, NULL );
	
	// set the ProgressProc callback function
	if( CheckCapabilityOperation(pRefChild, kNkMAIDCapability_ProgressProc, kNkMAIDCapOperation_Set ) ){
		stProc.pProc = (LPNKFUNC)ProgressProc;
		stProc.refProc = (NKREF)pRefChild;
		lResult = Command_CapSet( pRefChild->pObject, kNkMAIDCapability_ProgressProc, kNkMAIDDataType_CallbackPtr, (NKPARAM)&stProc, NULL, NULL );
	}

	return lResult;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL RemoveChild( LPRefObj pRefParent, SLONG lIDChild )
{
	LPRefObj pRefChild = GetRefChildPtr_ID( pRefParent, lIDChild );
	SLONG lResult = Close_Object( pRefChild->pObject );
	LPRefObj *pOldRefChildArray = (LPRefObj*)pRefParent->pRefChildArray;
	LPRefObj *pNewRefChildArray = NULL;
	ULONG i, n;
	if( pRefParent->ulChildCount > 1 ){
		pNewRefChildArray = (LPRefObj*)malloc( (pRefParent->ulChildCount - 1) * sizeof(LPRefObj) );
		for( n = 0, i = 0; i < pRefParent->ulChildCount; i++ ){
			if( ((LPRefObj)pOldRefChildArray[i])->lMyID != lIDChild )
				memmove( &pNewRefChildArray[n++], &pOldRefChildArray[i], sizeof(LPRefObj) );
		}
	}
	pRefParent->pRefChildArray = pNewRefChildArray;
	pRefParent->ulChildCount--;
	free( pRefChild->pObject );
	free( pRefChild->pCapArray );
	free( pRefChild );
	free( pOldRefChildArray );
	return lResult;
}
//------------------------------------------------------------------------------------------------------------------------------------
// Get pointer to reference of child object by child's ID
LPRefObj GetRefChildPtr_ID( LPRefObj pRefParent, SLONG lIDChild )
{
	LPRefObj pRefChild;
	ULONG ulCount;

	if(pRefParent == NULL)
		return NULL;

	for( ulCount = 0; ulCount < pRefParent->ulChildCount; ulCount++ ){
		if ( (pRefChild = GetRefChildPtr_Index(pRefParent, ulCount)) != NULL ) {
			if (pRefChild->lMyID == lIDChild)
				return pRefChild;
		}
	}

	return NULL;
}
//------------------------------------------------------------------------------------------------------------------------------------
// Get pointer to reference of child object by index
LPRefObj GetRefChildPtr_Index( LPRefObj pRefParent, ULONG ulIndex )
{
	if (pRefParent == NULL)
		return NULL;

	if( (pRefParent->pRefChildArray != NULL) && (ulIndex < pRefParent->ulChildCount) )
		return (LPRefObj)((LPRefObj*)pRefParent->pRefChildArray)[ulIndex];
	else
		return NULL;
}
//------------------------------------------------------------------------------------------------------------------------------------

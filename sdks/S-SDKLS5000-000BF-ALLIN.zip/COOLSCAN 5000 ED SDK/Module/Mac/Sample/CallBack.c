//================================================================================================
// Copyright Nikon Corporation - All rights reserved
//
// View this file in a non-proportional font, tabs = 3
//================================================================================================

#define _WINDOWS

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <mmsystem.h>
#include "Maid3.h"
#include	"MDSample.h"
#include	"PSDFile.h"

ULONG g_ulProgressValue = 0;// used in only ProgressProc
BOOL	g_bFirstCall = true;// used in only ProgressProc

//------------------------------------------------------------------------------------------------------------------------------------

void CALLPASCAL CALLBACK ModEventProc( NKREF refProc, ULONG ulEvent, NKPARAM data )
{
	SLONG lResult = FALSE;
	LPRefObj pRefParent = (LPRefObj)refProc, pRefChild = NULL;
	LPVOID* pOldRef = NULL, pNewRef = NULL;
	ULONG i = 0, n = 0;
	NkMAIDCallback	cbEventProc;

	switch(ulEvent){
		case kNkMAIDEvent_AddChild:
			lResult = AddChild( pRefParent, (SLONG)data );
			pRefChild = GetRefChildPtr_ID( pRefParent, (SLONG)data );
			// if Source object support Cap_EventProc, set SrcEventProc and enumerate children(Item) object. 
			if( CheckCapabilityOperation(pRefChild, kNkMAIDCapability_EventProc, kNkMAIDCapOperation_Set ) ) {
				cbEventProc.pProc = (LPNKFUNC)SrcEventProc;//
				cbEventProc.refProc = (NKREF)pRefChild;
				lResult = Command_CapSet( pRefChild->pObject, kNkMAIDCapability_EventProc, kNkMAIDDataType_CallbackPtr, (NKPARAM)&cbEventProc, NULL, NULL );
//				if ( pRefChild->ulChildCount > 0 )
					lResult = EnumChildrten( pRefChild->pObject );
			}
			break;
		case kNkMAIDEvent_RemoveChild:
			lResult = RemoveChild( pRefParent, (SLONG)data );
			break;
		case kNkMAIDEvent_WarmingUp:
			puts( "Event_WarmingUp to Module object is not supported." );
			break;
		case kNkMAIDEvent_WarmedUp:
			puts( "Event_WarmedUp to Module object is not supported." );
			break;
		case kNkMAIDEvent_CapChange:
			puts( "Event_CapChange to Module object is not supported." );
			break;
		case kNkMAIDEvent_OrphanedChildren:
			puts( "Event_OrphanedChildren to Module object is not supported." );
			break;
		default:
			puts( "Unknown Event to Module object occured." );
		}
}
//------------------------------------------------------------------------------------------------------------------------------------

void CALLPASCAL CALLBACK SrcEventProc( NKREF refProc, ULONG ulEvent, NKPARAM data )
{
	SLONG lResult = FALSE;
	LPRefObj pRefParent = (LPRefObj)refProc, pRefChild = NULL;
	LPVOID* pOldRef = NULL, pNewRef = NULL;
	ULONG i = 0, n = 0;
	SLONG lIndex = 0;
	NkMAIDCallback	cbEventProc;

	switch(ulEvent){
		case kNkMAIDEvent_AddChild:
			lResult = AddChild( pRefParent, (SLONG)data );
			pRefChild = GetRefChildPtr_ID( pRefParent, (SLONG)data );
			// if Item object support Cap_EventProc, set SrcEventProc and enumerate children(Data) object. 
			if( CheckCapabilityOperation(pRefChild, kNkMAIDCapability_EventProc, kNkMAIDCapOperation_Set ) ) {
				cbEventProc.pProc = (LPNKFUNC)ItmEventProc;//
				cbEventProc.refProc = (NKREF)pRefChild;
				lResult = Command_CapSet( pRefChild->pObject, kNkMAIDCapability_EventProc, kNkMAIDDataType_CallbackPtr, (NKPARAM)&cbEventProc, NULL, NULL );
//				if ( pRefChild->ulChildCount > 0 )
					lResult = EnumChildrten( pRefChild->pObject );
			}
			break;
		case kNkMAIDEvent_RemoveChild:
			lResult = RemoveChild( pRefParent, (SLONG)data );
			break;
		case kNkMAIDEvent_WarmingUp:
			puts( "Event_WarmingUp to Source object is not supported." );
			break;
		case kNkMAIDEvent_WarmedUp:
			puts( "Event_WarmedUp to Source object is not supported." );
			break;
		case kNkMAIDEvent_CapChange:
			// process, when an adapter or a film is inserted.
			if ( data == 0 ) {
				if( CheckCapabilityOperation(pRefParent, kNkMAIDCapability_EventProc, kNkMAIDCapOperation_Set ) ){
					cbEventProc.pProc = (LPNKFUNC)SrcEventProc;//
					cbEventProc.refProc = (NKREF)pRefParent;
					lResult = Command_CapSet(pRefParent->pObject, kNkMAIDCapability_EventProc, kNkMAIDDataType_CallbackPtr, (NKPARAM)&cbEventProc, NULL, NULL );
					if ( pRefParent->ulChildCount > 0 )
						lResult = EnumChildrten( pRefParent->pObject );
				}
			} else
				puts( "This event to Source object (one of kNkMAIDEvent_CapChange) is not supported." );
			break;
		case kNkMAIDEvent_OrphanedChildren:
			puts( "Event_OrphanedChildren to Source object is not supported." );
			break;
		default:
			puts( "Unknown Event to Source object occured." );
		}
}
//------------------------------------------------------------------------------------------------------------------------------------

void CALLPASCAL CALLBACK ItmEventProc( NKREF refProc, ULONG ulEvent, NKPARAM data )
{
	SLONG lResult = FALSE;
	LPRefObj pRefParent = (LPRefObj)refProc, pRefChild = NULL;
	LPVOID* pOldRef = NULL, pNewRef = NULL;
	ULONG i = 0, n = 0;
	NkMAIDCallback	cbEventProc;

	switch(ulEvent){
		case kNkMAIDEvent_AddChild:
			lResult = AddChild( pRefParent, (SLONG)data );
			pRefChild = GetRefChildPtr_ID( pRefParent, (SLONG)data );
			// if Data object support Cap_EventProc, set SrcEventProc. 
			if( CheckCapabilityOperation(pRefChild, kNkMAIDCapability_EventProc, kNkMAIDCapOperation_Set ) ) {
				cbEventProc.pProc = (LPNKFUNC)DatEventProc;
				cbEventProc.refProc = (NKREF)pRefChild;
				lResult = Command_CapSet(pRefChild->pObject, kNkMAIDCapability_EventProc, kNkMAIDDataType_CallbackPtr, (NKPARAM)&cbEventProc, NULL, NULL );
			}
			break;
		case kNkMAIDEvent_RemoveChild:
			lResult = RemoveChild( pRefParent, (SLONG)data );
			break;
		case kNkMAIDEvent_WarmingUp:
			puts( "Event_WarmingUp to Item object is not supported." );
			break;
		case kNkMAIDEvent_WarmedUp:
			puts( "Event_WarmedUp to Item object is not supported." );
			break;
		case kNkMAIDEvent_CapChange:
			puts( "kNkMAIDEvent_CapChange to Item object is not supported." );
			break;
		case kNkMAIDEvent_OrphanedChildren:
			puts( "kNkMAIDEvent_OrphanedChildren to Item object is not supported." );
			break;
		default:
			puts( "Unknown Event to Item object occured." );
		}
	}
//------------------------------------------------------------------------------------------------------------------------------------

void CALLPASCAL CALLBACK DatEventProc( NKREF refProc, ULONG ulEvent, NKPARAM data )
{
	LPRefObj	pRefParent = (LPRefObj)refProc;
	NkMAIDSize	stNkSize;

	switch(ulEvent){
		case kNkMAIDEvent_AddChild:
			puts( "kNkMAIDEvent_AddChild to Data object is not supported." );
			break;
		case kNkMAIDEvent_RemoveChild:
			puts( "kNkMAIDEvent_RemoveChild to Data object is not supported." );
			break;
		case kNkMAIDEvent_WarmingUp:
			puts( "Event_WarmingUp to Data object is not supported." );
			break;
		case kNkMAIDEvent_WarmedUp:
			puts( "kNkMAIDEvent_WarmedUp to Data object is not supported." );
			break;
		case kNkMAIDEvent_CapChange:// module notify that a capability is changed.
			switch(data) {
				case kNkMAIDCapability_Pixels:
					Command_CapGet( pRefParent->pObject, kNkMAIDCapability_Pixels, kNkMAIDDataType_SizePtr, (NKPARAM)&stNkSize, NULL, NULL );
					// New Image size is set in stNkSize.
					break;
				case kNkMAIDCapability_Coords:
					break;
				case kNkMAIDCapability_Focus:
					break;
				default:
					;
			}
			break;
		case kNkMAIDEvent_OrphanedChildren:
			puts( "kNkMAIDEvent_OrphanedChildren to Data object is not supported." );
			break;
		default:
			puts( "Unknown Event to Data object occured." );
	}
}
//------------------------------------------------------------------------------------------------------------------------------------

NKERROR CALLPASCAL CALLBACK DataProc( NKREF ref, LPVOID pDataInfo, LPVOID pData )
{
	ULONG ulTotalSize, ulOffset;
	LPVOID pCurrentBuffer;
	ULONG ulByte;
	SWORD	nImageMode, nPlaneCount, nDataType;
	char	filename[32];

	ulTotalSize = ((LPNkMAIDImageInfo)pDataInfo)->ulRowBytes * ((LPNkMAIDImageInfo)pDataInfo)->szTotalPixels.h;
	ulOffset = ((LPRefDeliver)ref)->ulOffset;

	switch( ((LPNkMAIDDataInfo)pDataInfo)->ulType ) {
		case kNkMAIDDataObjType_Image:
		case kNkMAIDDataObjType_Thumbnail:
			switch( ((LPNkMAIDImageInfo)pDataInfo)->ulColorSpace ) {
				case kNkMAIDColorSpace_LineArt:
					nImageMode = 0;
					nPlaneCount = 1;
					goto Transfer;
				case kNkMAIDColorSpace_Grey:
					nImageMode = 1;
					nPlaneCount = 1;
					goto Transfer;
				case kNkMAIDColorSpace_RGB:
				case kNkMAIDColorSpace_sRGB:
				case kNkMAIDColorSpace_Lab:
				case kNkMAIDColorSpace_LCH:
					nImageMode = 3;
					nPlaneCount = 3;
					goto Transfer;
				case kNkMAIDColorSpace_CMYK:
					nImageMode = 4;
					nPlaneCount = 4;
				Transfer:
					if( ulOffset == 0 && ((LPRefDeliver)ref)->pBuffer == NULL ) {
						((LPRefDeliver)ref)->pBuffer = malloc( ulTotalSize );
						if ( ((LPRefDeliver)ref)->pBuffer == NULL ) {
							puts( "There is not enough memory." );
							return kNkMAIDResult_OutOfMemory;
						}
					}
					pCurrentBuffer = (LPVOID)((ULONG)((LPRefDeliver)ref)->pBuffer + ulOffset);
					ulByte = ((LPNkMAIDImageInfo)pDataInfo)->ulRowBytes * ((LPNkMAIDImageInfo)pDataInfo)->rData.h;
					memmove( pCurrentBuffer, pData, ulByte);
					ulOffset += ulByte;

					if( ulOffset < ulTotalSize )
						((LPRefDeliver)ref)->ulOffset = ulOffset;
					else {
						// when data transfer is complete, save image as Photoshop file.
						nDataType =  ( ((LPNkMAIDImageInfo)pDataInfo)->wBits[0] <= 8 ) ? 1 : 2;
						sprintf( filename, "Image%02d.psd", ((LPRefDeliver)ref)->lID );
						SavePSDfile(
							((LPRefDeliver)ref)->pBuffer,		// pointer to image data
							filename,		// file name
							((LPNkMAIDImageInfo)pDataInfo)->szTotalPixels.w,	// acquired image size(width)
							((LPNkMAIDImageInfo)pDataInfo)->szTotalPixels.h,	// acquired image size(height)
							nImageMode,	// Black & White:0  Grayscale:1  RGB:3  CMYK:4
							nPlaneCount,// Exp. Grayscale:1  RGB:3  CMYK:4
							nDataType	// if bits depth is 8, nDataType = 1. if bits depth is more than 8, nDataType = 2.
						);
					}
					break;
				default:
					break;
			}
			break;
		default:
			puts( "DataProc received data unsupported type." );
	}
	
	return kNkMAIDResult_NoError;
}
//------------------------------------------------------------------------------------------------------------------------------------

void CALLPASCAL CALLBACK CompletionProc(
  			LPNkMAIDObject	pObject,			// module, source, item, or data object
			ULONG				ulCommand,		// Command, one of eNkMAIDCommand
			ULONG				ulParam,			// parameter for the command
			ULONG				ulDataType,		// Data type, one of eNkMAIDDataType
			NKPARAM			data,				// Pointer or long integer
			NKREF				refComplete,	// Reference set by client
			NKERROR			nResult )		// One of eNkMAIDResult)
{
	((LPRefCompletionProc)refComplete)->nResult = nResult;
	(*((LPRefCompletionProc)refComplete)->pulCount) ++;

	// if the Command is CapStart acquire, we terminate RefDeliver.
	if(ulCommand == kNkMAIDCommand_CapStart && ulParam == kNkMAIDCapability_Acquire) {
		LPRefDeliver pRefDeliver = (LPRefDeliver)((LPRefCompletionProc)refComplete)->pRef;
		if ( pRefDeliver != NULL ) {
			if ( pRefDeliver->pBuffer != NULL )
				free( pRefDeliver->pBuffer );
			free( pRefDeliver );
		}
	}
	// terminate refComplete.
	if ( refComplete != NULL )
		free( refComplete );

}
//------------------------------------------------------------------------------------------------------------------------------------

void CALLPASCAL CALLBACK ProgressProc(
		ULONG				ulCommand,			// Command, one of eNkMAIDCommand
		ULONG				ulParam,				// parameter for the command
		NKREF				refProc,				// Reference set by client
		ULONG				ulDone,				// Numerator
		ULONG				ulTotal )			// Denominator
{
	ULONG	ulNewProgressValue, ulCount;

	if ( ulTotal == 0 ) {
		// when we don't know how long this process, we show such as barber's pole.
		if ( ulDone == 1 ) {
			ulNewProgressValue = timeGetTime();
			if( (ulNewProgressValue < g_ulProgressValue) || (ulNewProgressValue > g_ulProgressValue + 500) ) {
				printf( "c" );
				g_ulProgressValue = ulNewProgressValue;
			}
		} else if ( ulDone == 0 ) {
				printf( "o" );
		}
	} else {
		// when we know how long this process, we show progress bar.
		if ( ulDone == 0 ) {
			if ( g_bFirstCall == true ) {
				g_ulProgressValue = 0;
				g_bFirstCall = false;
				printf("\n0       20        40        60        80        100");
				printf("\n---------+---------+---------+---------+---------+\n");
			}
		} else {
			// show progress bar
			ulNewProgressValue = (50 * ulDone + ulTotal - 1) / ulTotal;
			ulCount = ulNewProgressValue - g_ulProgressValue;
			while ( ulCount-- )
				printf( "]" );
			g_ulProgressValue = ulNewProgressValue;
			if ( ulDone == ulTotal ) {
				printf( "\n" );
				g_bFirstCall = true;
				g_ulProgressValue = 0;
			}
		}
	}
}
//------------------------------------------------------------------------------------------------------------------------------------

ULONG CALLPASCAL CALLBACK UIRequestProc( NKREF ref, LPNkMAIDUIRequestInfo pUIRequest )
{
	short	 nRet = kNkMAIDUIRequestResult_None;
	char	sAns[256];

	// display message
	if (pUIRequest->lpPrompt)
		printf( "\n%s\n", pUIRequest->lpPrompt );
	if (pUIRequest->lpDetail)
		printf( "\n%s\n", pUIRequest->lpDetail );

	// get an answer
	switch( pUIRequest->ulType ){
		case kNkMAIDUIRequestType_Ok:
			do {
				printf("\nPress 'O' key. ('O': OK)\n>");
				scanf( "%s", sAns );
			} while ( *sAns != 'o' && *sAns != 'O' );
			nRet = kNkMAIDUIRequestResult_Ok;
			break;
		case kNkMAIDUIRequestType_OkCancel:
			do {
				printf("\nPress 'O' or 'C' key. ('O': OK   'C': Cancel)\n>");
				scanf( "%s", sAns );
			} while ( *sAns != 'o' && *sAns != 'O' && *sAns != 'c' && *sAns != 'C' );
			if ( *sAns == 'o' || *sAns == 'O' )
				nRet = kNkMAIDUIRequestResult_Ok;
			else if ( *sAns == 'c' || *sAns == 'C' )
				nRet = kNkMAIDUIRequestResult_Cancel;
			break;
		case kNkMAIDUIRequestType_YesNo:
			do {
				printf("\nPress 'Y' or 'N' key. ('Y': Yes   'N': No)\n>");
				scanf( "%s", sAns );
			} while ( *sAns != 'y' && *sAns != 'Y' && *sAns != 'n' && *sAns != 'N' );
			if ( *sAns == 'y' || *sAns == 'Y' )
				nRet = kNkMAIDUIRequestResult_Yes;
			else if ( *sAns == 'n' || *sAns == 'N' )
				nRet = kNkMAIDUIRequestResult_No;
			break;
		case kNkMAIDUIRequestType_YesNoCancel:
			do {
				printf("\nPress 'Y' or 'N' or 'C' key. ('Y': Yes   'N': No   'C': Cancel)\n>");
				scanf( "%s", sAns );
			} while ( *sAns != 'y' && *sAns != 'Y' && *sAns != 'n' && *sAns != 'N' && *sAns != 'c' && *sAns != 'C' );
			if ( *sAns == 'y' || *sAns == 'Y' )
				nRet = kNkMAIDUIRequestResult_Yes;
			else if ( *sAns == 'n' || *sAns == 'N' )
				nRet = kNkMAIDUIRequestResult_No;
			else if ( *sAns == 'c' || *sAns == 'C' )
				nRet = kNkMAIDUIRequestResult_Cancel;
			break;
		default:
			nRet = kNkMAIDUIRequestResult_None;
	}

	return nRet;
}
//------------------------------------------------------------------------------------------------------------------------------------

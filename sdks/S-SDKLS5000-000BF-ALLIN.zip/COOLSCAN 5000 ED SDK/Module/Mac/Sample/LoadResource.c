//================================================================================================
// Copyright Nikon Corporation - All rights reserved
//
//================================================================================================

/*****************************************************************************
  pFileSpec     : Pointer to FSSpec of Module file
  *ppProcEntry  : Pointer to EntryProc of Module
  *pnFileRefNum : file reference number of Module file
  *pConnID      : Connection ID of Module's code fragment (PPC version only)
*****************************************************************************/
LoadModule( FSSpecPtr pFileSpec, Ptr* ppProcEntry, short* pnFileRefNum,	CFragConnectionID* pConnID )
{
	#ifdef powerc
		
		if ( ( *pnFileRefNum = FSpOpenResFile( pFileSpec, fsRdWrShPerm) ) != -1 ) 	// open resource fork
			GetDiskFragment( pFileSpec, 0L, kCFragGoesToEOF, 0L, kLoadCFrag, pConnID, ppProcEntry, 0L );

	#else

		Handle	hHandle;	
		if ( ( *pnFileRefNum = FSpOpenResFile( pFileSpec, fsRdWrShPerm) ) != -1 ){	// open resource fork
			hHandle = Get1IndResource ( 'MAID', 1 );			
			if ( ( ResError() == noErr ) && ( hHandle != 0L ) ) {
				DetachResource( hHandle );
				HLockHi ( hHandle );
				*ppProcEntry = (Ptr)*hHandle;
				HoldMemory( *hHandle, GetHandleSize( hHandle ) );				
			}
		}
		
	#endif
}

/*****************************************************************************
  pProcEntry    : Pointer to EntryProc of Module
  nFileRefNum   : file reference number of Module file
  ConnID        : Connection ID of Module's code fragment (PPC version only)
*****************************************************************************/
UnloadModule( Ptr pProcEntry, short nFileRefNum, CFragConnectionID ConnID )
{
	#ifdef powerc

		CloseConnection( ConnID );

	#else

		Handle	hHandle = RecoverHandle( pProcEntry );
		if( hHandle != 0L )
		{
			UnholdMemory( *hHandle, GetHandleSize( hHandle ) );
			HUnlock( hHandle );
			DisposeHandle( hHandle );
		}

	#endif

		CloseResFile( nFileRefNum );// close resource fork
}

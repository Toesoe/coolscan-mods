//================================================================================================
// Copyright Nikon Corporation - All rights reserved
//
// PSDFile.cpp
//
// View this file in a non-proportional font, tabs = 3
//================================================================================================

#define _WINDOWS

#include	<stdio.h>
#include "NkTypes.h"		// Special cross-platform typedefs and macros
#include	"PSDFile.h"

/*	SavePSDfile()	: save Photoshop image file
	pInData			: saved data (if this data is 2 bytes/pixel�Athe order is HSB-LSB)
	pFileName		: writen file path
	nImageMode		: ImageMode(LineArt = 0, GrayScale = 1, Color = 3, CMYK = 4)
	nPlaneCount		: Number of planes(GrayScale = 1, Color = 3, CMYK = 4, Color with IR = 4)
	nDataType		: bits depth(8bit = 1, 16bit = 2)
*/
SWORD SavePSDfile(
					LPVOID pInData,
					LPSTR pFileName,
					ULONG dwXPixel,
					ULONG dwYPixel,
					SWORD nImageMode,
					SWORD nPlaneCount,
					SWORD nDataType )
{
	SWORD nRet = TRUE;
	PSDFILEHEADER *pstFileHeader;

	ULONG dwImageSize;
	if (nImageMode == 0)
		dwImageSize = (dwXPixel + 7) / 8 * dwYPixel;// ImageMode is LineArt.
	else
		dwImageSize = dwXPixel * nPlaneCount * nDataType * dwYPixel;// ImageMode is others.

	// allocate memory for file header
	if ( (pstFileHeader = (PSDFILEHEADER *)GlobalAlloc(GPTR, sizeof(PSDFILEHEADER))) == NULL )
		nRet = FALSE;

	if ( nRet == TRUE ) {
		// make file header for Photoshop image file
		MakePSDHeader(pstFileHeader, dwXPixel, dwYPixel, nImageMode, nPlaneCount, nDataType);
		// save the image data
		nRet = PSDSave(pFileName, pstFileHeader, dwImageSize, pInData);

		GlobalFree(pstFileHeader);
	}

	return nRet;
}

/* MakePSDHeader(): Make header for Photoshop image file
	pstFileHeader	: pointer to the header of Photoshop image file
	dwXPixel			: number of pixels left to right
	dwYPixel			: number of pixels up to down
	nImageMode		: ImageMode(LineArt = 0, GrayScale = 1, Color = 3, CMYK = 4)
	nPlaneCount		: Number of planes(GrayScale = 1, Color = 3, CMYK = 4, Color with IR = 4)
	nDataType		: bits depth(8bit = 1, 16bit = 2)
*/
void MakePSDHeader(	PSDFILEHEADER *pstFileHeader,
					ULONG dwXPixel,
					ULONG dwYPixel,
					SWORD nImageMode,
					SWORD nPlaneCount,
					SWORD nDataType )
{
	memcpy(pstFileHeader->Signature, "8BPS", 4);
	pstFileHeader->nVersion = 0x100;
	pstFileHeader->nPlaneCount = (UWORD)nPlaneCount << 8;
	pstFileHeader->dwRow = ConvertEndian(dwYPixel);
	pstFileHeader->dwColumn = ConvertEndian(dwXPixel);

	if (nImageMode == 0)
		pstFileHeader->nBits = 0x100;
	else {
		if (nDataType == 1)
			pstFileHeader->nBits = 0x800;
		else
			pstFileHeader->nBits = 0x1000;
	}

	pstFileHeader->nMode = (UWORD)nImageMode << 8;
	pstFileHeader->nCompression = 0;

	return;
}

/* PSDSave()		: save the image data
	pFileName		: pointer to failename string
	pstFileHeader	: pointer to the header of Photoshop image file
	dwImageSize		: image size in total pixel number
	pInData			: saved data
*/
SWORD PSDSave(	LPSTR pFileName,
				PSDFILEHEADER *pstFileHeader,
				ULONG dwImageSize,
				LPVOID pInData )
{
	UWORD i;
	ULONG j;
	UCHAR *pchGrayData, *pchData;
	UWORD *pwData, *pwGrayData;
	UCHAR *pData;
	UWORD *pwConvertedData;
	UWORD wBits = pstFileHeader->nBits >> 8;
	UWORD wPlaneCount = pstFileHeader->nPlaneCount >> 8;
	ULONG dwTotalWrite;
	ULONG dwSize = dwImageSize / wPlaneCount;

	FILE *stream;
	if ( (stream = fopen(pFileName, "wb") ) == NULL)
		return FALSE;

	dwTotalWrite = fwrite(pstFileHeader, 1, sizeof(PSDFILEHEADER), stream);
	pchData = (UCHAR*)GlobalAlloc(GPTR, dwSize); // allocate memory for buffer size of one plane

	switch (wBits) {
		case 1:
			dwTotalWrite += fwrite(pchData, dwSize, sizeof(UCHAR), stream);
			break;
		case 8:
			for (i = 0; i < wPlaneCount; i++) {
				pData = pchData;
				pchGrayData = ((UCHAR*)pInData) + i;
				for (j = 0; j < dwSize; j++) {
					*pData++ = *pchGrayData;
					pchGrayData = pchGrayData + wPlaneCount;
				}

				dwTotalWrite += fwrite(pchData, dwSize, sizeof(UCHAR), stream);
			}
			break;
		case 16:
			// if bits depth is 16, swap LSB and HSB
			pData = (UCHAR*)pInData;
			pwConvertedData = (UWORD*)pInData;
			for (j = 0; j < (dwImageSize >> 1); j++) {
				*pwConvertedData = *(UWORD*)pData;
				*pwConvertedData++ = (((UWORD)*pData++) << 8) | (((UWORD)*(pData+1)) & 0x00ff);
				pData++;
			}

			for (i = 0; i < wPlaneCount; i++) {
				pwData = (UWORD*)pchData;
				pwGrayData = ((UWORD*)pInData) + i;
				for (j = 0; j < (dwSize / 2); j++) {
					*pwData++ = *pwGrayData;
					pwGrayData = pwGrayData + wPlaneCount;
				}

				dwTotalWrite += fwrite(pchData, dwSize / 2, sizeof(UWORD), stream);
			}
			break;
		default:
			return FALSE;
	}

	fclose(stream);

	if (pchData != NULL)
		GlobalFree(pchData);

	return TRUE;
}

ULONG ConvertEndian(ULONG InLong)
{
	ULONG OutLong, first, second, third, fourth;

	fourth		= (InLong & 0xff000000) >> 24;
	third		= (InLong & 0x00ff0000) >> 8;
	second		= (InLong & 0x0000ff00) << 8;
	first		= (InLong & 0x000000ff) << 24;

	return OutLong = first | second | third | fourth;
}

///////////////////////////EOF/////////////////////////////
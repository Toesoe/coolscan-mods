//================================================================================================
// Copyright Nikon Corporation - All rights reserved
//
// View this file in a non-proportional font, tabs = 3
//================================================================================================

#define	_WINDOWS

#include	<stdio.h>
#include	"nkwinmac.h"
#include	"maid3.h"
#include	"maid3ex.h"
#include	"MDSample.h"

LPMAIDEntryPointProc	g_pMAIDEntryPoint;

//------------------------------------------------------------------------------------------------------------------------------------

void main()
{
	LPRefObj	pRefDat, pRefItm, pRefSrc, pRefMod;
	ULONG	ulID = 0;
	NkMAIDCallback	stProc;
	BOOL	bResult;
	char	buf[256];
	UWORD wSel;

	// Load Module_File (LS4000.MD3)
	bResult = Load_Module("LS5000.MD3");
	if (bResult == false)
		return;

	pRefMod = (LPRefObj)malloc(sizeof(RefObj));
	InitRefObj( pRefMod );

	//	Open Module_Object
	pRefMod->pObject = (LPNkMAIDObject)malloc(sizeof(NkMAIDObject));
	pRefMod->pObject->refClient = (NKREF)pRefMod;
	bResult = Open_Object(  NULL,					// When Module_Object will be opend, "pParentObj" is "NULL".
									pRefMod->pObject,	// Pointer to Module_Object 
									ulID );				// Module_Object_ID set by Client
	if (bResult == true)
		printf("Module object is opened.\n");
	else {
			printf("Module object can't be opened.\n");
			goto FREE_REFMOD;
	}


	//	Enumerate Capabilities that the Module has.
	EnumCapabilities( pRefMod->pObject, &(pRefMod->ulCapCount), &(pRefMod->pCapArray), NULL, NULL );

	//	Set the Capability of UIRequest callback function.
	if( CheckCapabilityOperation( pRefMod, kNkMAIDCapability_UIRequestProc, kNkMAIDCapOperation_Set ) ){
		stProc.pProc = (LPNKFUNC)UIRequestProc;
		stProc.refProc = (NKREF)pRefMod;
		bResult = Command_CapSet( pRefMod->pObject, kNkMAIDCapability_UIRequestProc, kNkMAIDDataType_CallbackPtr, (NKPARAM)&stProc, NULL, NULL );
	}

	//	Set the Capability of EventProc callback function.
	if( CheckCapabilityOperation( pRefMod, kNkMAIDCapability_EventProc, kNkMAIDCapOperation_Set )  ){
		stProc.pProc = (LPNKFUNC)ModEventProc;
		stProc.refProc = (NKREF)pRefMod;
		bResult = Command_CapSet( pRefMod->pObject, kNkMAIDCapability_EventProc, kNkMAIDDataType_CallbackPtr, (NKPARAM)&stProc, NULL, NULL);
	}

	//	Enumerate the Module_Objet's Children. (Open Source_Object, Item_Object and Data_Object)
	bResult = EnumChildrten( pRefMod->pObject );

	// Set default Data object. (first frame image is default)
	pRefSrc = GetRefChildPtr_Index( pRefMod, 0 );
	pRefItm = GetRefChildPtr_Index( pRefSrc, 0 );
	pRefDat = GetRefChildPtr_ID( pRefItm, kNkMAIDDataObjType_Image );
	if ( pRefDat != NULL )
		printf("Data object is opened.\n");
	else {
		printf("Data object can't be opened.\n");
		goto CLOSE_MODULE;
	}

	// command loop
	do {
		printf( "\nSelect (1-3, 11-15, 0)\n" );
		printf( " 1. Select Device            2. Select frame No.          3. Set scan condition\n" );
		printf( "11. Autofocus               12. Prescan                  13. ThumbnailScan\n" );
		printf( "14. FinalScan               15. Eject\n" );
		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );

		switch( wSel )
		{
			case 1:// Select Device
				SelectDevice( pRefMod, &pRefSrc );
				pRefItm = GetRefChildPtr_Index( pRefSrc, 0 );
				pRefDat = GetRefChildPtr_ID( pRefItm, kNkMAIDDataObjType_Image );
				break;
			case 2:// Select frame No.
				SelectFrameNum( pRefSrc, &pRefItm );
				pRefDat = GetRefChildPtr_ID( pRefItm, kNkMAIDDataObjType_Image );
				break;
			case 3:// Set scan condition
				SetScanCondition( pRefDat );
				break;
			case 11:// Perform autofocus
				IssueAutofocus( pRefDat );
				break;
			case 12:// Perform prescan
				IssuePrescan( pRefDat );
				break;
			case 13:// Perform thumbnail scan
				IssueThumbnail( pRefSrc );
				break;
			case 14:// Perform final scan
				IssueScan( pRefDat );
				break;
			case 15:// eject film
				IssueEject( pRefSrc );
				break;
			default:
				wSel = 0;
		}
	} while( wSel > 0 );

// Close Module_Object
CLOSE_MODULE:
	bResult = Close_Module( pRefMod );
	if (bResult == true)
		printf("Module object is closed.\n");

// Free memories allocated in this function.
FREE_REFMOD:
	if ( pRefMod->pObject != NULL )
		free( pRefMod->pObject );
	if ( pRefMod != NULL )
		free( pRefMod );
}

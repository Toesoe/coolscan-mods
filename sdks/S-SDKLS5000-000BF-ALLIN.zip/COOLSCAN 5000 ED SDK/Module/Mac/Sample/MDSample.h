//================================================================================================
// Copyright Nikon Corporation - All rights reserved
//
// View this file in a non-proportional font, tabs = 3
//================================================================================================

/////////////////////////////////////////////////////////////////////////////
// Structures

#pragma pack(push, 2)

	typedef struct tagRefObj
	{
		LPNkMAIDObject	pObject;
		SLONG lMyID;
		LPVOID pRefParent;
		ULONG ulChildCount;
		LPVOID pRefChildArray;
		ULONG ulCapCount;
		LPNkMAIDCapInfo pCapArray;
	} RefObj, *LPRefObj;

	typedef struct tagRefCompletionProc
	{
//		BOOL bEnd;
		ULONG* pulCount;
		NKERROR nResult;
//		LPVOID pcProgressDlg;
		LPVOID pRef;
	} RefCompletionProc, *LPRefCompletionProc;

	typedef struct tagRefDeliver
	{
		LPVOID pBuffer;
		ULONG ulOffset;
		ULONG ulTotalLines;
		SLONG	lID;
	} RefDeliver, *LPRefDeliver;

	typedef struct tagPSDFileHeader
	{
		char	type[5];
		char	space11[1];
		char	space01[6];
		short	Planecount; 	//0004 if RGB, this is 0003
		long	rowPixels;
		long	columnPixels;
		short	bits; 			//0008 means 8bit. 16bit also supported
		short	mode; 			//0004 means CMYK, Gray -- 1, RGB -- 3
		char	space02[14];
	} PSDFileHeader, *LPPSDFileHeader;

	typedef struct tagRefSpecialCap
	{
		ULONG ulCapID;
		ULONG ulCapValue;
//		ULONG ulCapType;
		ULONG ulUIID;
	} RefSpecialCap, *LPRefSpecialCap;

#pragma pack(pop)


/////////////////////////////////////////////////////////////////////////////
// Prototype

SLONG	CallMAIDEntryPoint( 
		LPNkMAIDObject	pObject,				// module, source, item, or data object
		ULONG				ulCommand,			// Command, one of eNkMAIDCommand
		ULONG				ulParam,				// parameter for the command
		ULONG				ulDataType,			// Data type, one of eNkMAIDDataType
		NKPARAM			data,					// Pointer or long integer
		LPNKFUNC			pfnComplete,		// Completion function, may be NULL
		NKREF				refComplete );		// Value passed to pfnComplete
SLONG	Command_Async( LPNkMAIDObject pobject);
BOOL	Command_CapSet( LPNkMAIDObject pobject, ULONG ulParam, ULONG ulDataType, NKPARAM pData, LPNKFUNC pfnComplete, NKREF refComplete );
BOOL	Command_CapGet( LPNkMAIDObject pobject, ULONG ulParam, ULONG ulDataType, NKPARAM pData, LPNKFUNC pfnComplete, NKREF refComplete );
BOOL	Command_CapStart( LPNkMAIDObject pobject, ULONG ulParam, LPNKFUNC pfnComplete, NKREF refComplete );
BOOL	Command_CapGetArray(LPNkMAIDObject pobject, ULONG ulParam, ULONG ulDataType, NKPARAM pData, LPNKFUNC pfnComplete, NKREF refComplete );

void	CALLPASCAL CALLBACK ModEventProc( NKREF refProc, ULONG ulEvent, NKPARAM data );
void	CALLPASCAL CALLBACK SrcEventProc( NKREF refProc, ULONG ulEvent, NKPARAM data );
void	CALLPASCAL CALLBACK ItmEventProc( NKREF refProc, ULONG ulEvent, NKPARAM data );
void	CALLPASCAL CALLBACK DatEventProc( NKREF refProc, ULONG ulEvent, NKPARAM data );
void	CALLPASCAL CALLBACK ProgressProc( ULONG ulCommand, ULONG ulParam, NKREF refProc, ULONG ulDone, ULONG ulTotal );
ULONG	CALLPASCAL CALLBACK UIRequestProc( NKREF ref, LPNkMAIDUIRequestInfo pUIRequest );
void	CALLPASCAL CALLBACK CompletionProc( LPNkMAIDObject pObject, ULONG ulCommand, ULONG ulParam, ULONG ulDataType, NKPARAM data, NKREF refComplete, NKERROR nResult );
NKERROR	CALLPASCAL CALLBACK DataProc( NKREF ref, LPVOID pDataInfo, LPVOID pData );

void	InitRefObj( LPRefObj pRef );
BOOL	Load_Module( char* Path );
BOOL	Open_Object( NkMAIDObject* pParentObj, NkMAIDObject* pChildObj, ULONG ulChildID );
BOOL	Close_Module( LPRefObj pRefMod );
BOOL	Close_Object( LPNkMAIDObject pObject );
BOOL	EnumCapabilities( LPNkMAIDObject pobject, ULONG* pulCapCount, LPNkMAIDCapInfo* ppCapArray, LPNKFUNC pfnComplete, NKREF refComplete );
BOOL	EnumChildrten( LPNkMAIDObject pobject );
BOOL	AddChild( LPRefObj pRefParent, SLONG lIDChild );
BOOL	RemoveChild( LPRefObj pRefParent, SLONG lIDChild );
void	IdleLoop( LPNkMAIDObject pObject, ULONG* pulCount, ULONG ulEndCount );

SLONG	SelectDevice( LPRefObj pRefMod, LPRefObj *ppRefSrc );
SLONG SelectFrameNum( LPRefObj pRefSrc, LPRefObj *ppRefItm );
void	SetScanCondition( LPRefObj pRefDat );
void	SetNegative( LPRefObj pRefDat );
void	SetNkColorSpace( LPRefObj pRefDat );
void	SetResolution( LPRefObj pRefDat );
void	SetRectangle( LPRefObj pRefDat );
void	SetGamma( LPRefObj pRefDat );
void	SetBitDepth( LPRefObj pRefDat );
void	SetSpecialCapability( LPRefObj pRefDat, ULONG ulID );
ULONG	ShowSpecialCapabilityMenu( LPRefObj pRefDat, ULONG *pulSpecialCapArray, ULONG ulNumOfSelector );
char*	GetNkColorSpaceString( char *psColorspace, SLONG ulValue );
void	IssuePrescan( LPRefObj pRefDat );
void	IssueAutofocus( LPRefObj pRefDat );
void	IssueEject(LPRefObj pRefSrc);
void	IssueScan( LPRefObj pRefDat );
void	IssueThumbnail( LPRefObj pRefSrc );

LPNkMAIDCapInfo	GetCapInfo( LPRefObj pRef, ULONG ulID );
BOOL	CheckCapabilityOperation( LPRefObj pRef, ULONG ulID, ULONG ulOperations );
LPRefObj	GetRefChildPtr_Index( LPRefObj pRefParent, ULONG ulIndex );
LPRefObj	GetRefChildPtr_ID( LPRefObj pRefParent, SLONG lIDChild );
ULONG CountSpecialCap(LPRefObj pRef);


/////////////////////////////////////////////////////////////////////////////
// Static variables

extern LPMAIDEntryPointProc g_pMAIDEntryPoint;

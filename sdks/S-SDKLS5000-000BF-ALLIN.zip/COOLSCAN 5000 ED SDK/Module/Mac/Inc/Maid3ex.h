/*********************************************************/
//	MAID3EX.H
//		Scanner's Extra definition of maid3.h
//
/*********************************************************/
#ifndef _MAID3EX_H
#define _MAID3EX_H

#include "maid3.h"

///////////////////////////////////////////////////////////
//	Vendor color space
//
enum eNkMAIDColorSpaceVender
{
	kNkMAIDColorSpace_RGBD					= kNkMAIDColorSpace_VendorBase + 0x01
};

///////////////////////////////////////////////////////////
//	Vendor capability
//		Scanner's vendor capability range is VendorBase + 0x00 - 0xFF.
//		Over 0x100 is for camera's vendor capability.
//
enum eNkMAIDCapabilityVender
{
	kNkMAIDCapability_InterpolationMethod	= kNkMAIDCapability_VendorBase + 0x01,	//	Not in use from LS4000
	kNkMAIDCapability_Sharpness				= kNkMAIDCapability_VendorBase + 0x02,	//	Not in use from
	kNkMAIDCapability_NegativePrescanMode	= kNkMAIDCapability_VendorBase + 0x03,	//	Not in use from LS4000
	kNkMAIDCapability_IntegratedPreview		= kNkMAIDCapability_VendorBase + 0x06,	//	From LS4000
	kNkMAIDCapability_Monochrome			= kNkMAIDCapability_VendorBase + 0x07,	//	From LS4000
	kNkMAIDCapability_MonochromeDefault		= kNkMAIDCapability_VendorBase + 0x08,	//	From LS4000
	kNkMAIDCapability_Kodachrome			= kNkMAIDCapability_VendorBase + 0x0C,	//	From LS4000
	kNkMAIDCapability_KodachromeDefault		= kNkMAIDCapability_VendorBase + 0x0D,	//	From LS4000

	kNkMAIDCapability_SDCGroup				= kNkMAIDCapability_VendorBase + 0x10,
//	kNkMAIDCapability_SDCOn					= kNkMAIDCapability_VendorBase + 0x11,
	kNkMAIDCapability_SDCMode				= kNkMAIDCapability_VendorBase + 0x12,
	kNkMAIDCapability_SDCDefect				= kNkMAIDCapability_VendorBase + 0x13,	//	Not in use from LS4000
	kNkMAIDCapability_SDCPreview			= kNkMAIDCapability_VendorBase + 0x14,
	kNkMAIDCapability_SDCHelp				= kNkMAIDCapability_VendorBase + 0x15,
	kNkMAIDCapability_ROCGEMEnable			= kNkMAIDCapability_VendorBase + 0x1A,	//	From LS4000
	kNkMAIDCapability_ROCGEMArea			= kNkMAIDCapability_VendorBase + 0x1B,	//	From LS4000
	kNkMAIDCapability_ROCGEMAreaBase		= kNkMAIDCapability_VendorBase + 0x1C,	//	From LS4000
	kNkMAIDCapability_ROCGEMMode			= kNkMAIDCapability_VendorBase + 0x1D,	//	From LS4000

	kNkMAIDCapability_CMLGroup				= kNkMAIDCapability_VendorBase + 0x20,
	kNkMAIDCapability_CMLMode				= kNkMAIDCapability_VendorBase + 0x21,
	kNkMAIDCapability_CMLInputProfile		= kNkMAIDCapability_VendorBase + 0x22,
	kNkMAIDCapability_CMLOutputProfile		= kNkMAIDCapability_VendorBase + 0x23,

	kNkMAIDCapability_AutoFeeder			= kNkMAIDCapability_VendorBase + 0x31,
	kNkMAIDCapability_DefaultOrientation	= kNkMAIDCapability_VendorBase + 0x32,

	kNkMAIDCapability_FocusGroup			= kNkMAIDCapability_VendorBase + 0x35,
	kNkMAIDCapability_FocusMove				= kNkMAIDCapability_VendorBase + 0x36,
	kNkMAIDCapability_FocusHelp				= kNkMAIDCapability_VendorBase + 0x37,
	kNkMAIDCapability_SelfAutoFocus			= kNkMAIDCapability_VendorBase + 0x3A,	//	From LS4000
	kNkMAIDCapability_SelfAutoFocusHelp		= kNkMAIDCapability_VendorBase + 0x3B,	//	From LS8000
	kNkMAIDCapability_SelfAutoFocusGroup	= kNkMAIDCapability_VendorBase + 0x3C,	//	From LS8000

	kNkMAIDCapability_AnalogGainMaster		= kNkMAIDCapability_VendorBase + 0x50,
	kNkMAIDCapability_AnalogGainRed			= kNkMAIDCapability_VendorBase + 0x51,
	kNkMAIDCapability_AnalogGainGreen		= kNkMAIDCapability_VendorBase + 0x52,
	kNkMAIDCapability_AnalogGainBlue		= kNkMAIDCapability_VendorBase + 0x53,
	kNkMAIDCapability_AnalogGainGray		= kNkMAIDCapability_VendorBase + 0x54,
	kNkMAIDCapability_AnalogGainHelp		= kNkMAIDCapability_VendorBase + 0x55,
	kNkMAIDCapability_AnalogGainGroup		= kNkMAIDCapability_VendorBase + 0x56,
	kNkMAIDCapability_BaseGainRed			= kNkMAIDCapability_VendorBase + 0x57,
	kNkMAIDCapability_BaseGainGreen			= kNkMAIDCapability_VendorBase + 0x58,
	kNkMAIDCapability_BaseGainBlue			= kNkMAIDCapability_VendorBase + 0x59,
	kNkMAIDCapability_BaseGainGray			= kNkMAIDCapability_VendorBase + 0x5A,

	kNkMAIDCapability_QualityModeNew		= kNkMAIDCapability_VendorBase + 0x70,
	kNkMAIDCapability_QualityModeHelp		= kNkMAIDCapability_VendorBase + 0x71,
	kNkMAIDCapability_QualityModeGroup		= kNkMAIDCapability_VendorBase + 0x72,

	kNkMAIDCapability_BoundaryOffset		= kNkMAIDCapability_VendorBase + 0x75,
	kNkMAIDCapability_ReloadThumbnail		= kNkMAIDCapability_VendorBase + 0x76,
	kNkMAIDCapability_BoundaryGroup			= kNkMAIDCapability_VendorBase + 0x77,
	kNkMAIDCapability_AdvancedMode			= kNkMAIDCapability_VendorBase + 0x78,
	kNkMAIDCapability_ClearTimer			= kNkMAIDCapability_VendorBase + 0x79,
	kNkMAIDCapability_FeedVendor			= kNkMAIDCapability_VendorBase + 0x7A,
	kNkMAIDCapability_SDCThreshold			= kNkMAIDCapability_VendorBase + 0x7C,	//	Not in use from LS4000
	kNkMAIDCapability_SDCMearge				= kNkMAIDCapability_VendorBase + 0x7D,	//	Not in use from LS4000
	kNkMAIDCapability_IrProcess				= kNkMAIDCapability_VendorBase + 0x7E,
	kNkMAIDCapability_OutputBits			= kNkMAIDCapability_VendorBase + 0x7F,
	kNkMAIDCapability_ExposureOnly			= kNkMAIDCapability_VendorBase + 0x80,
	kNkMAIDCapability_SetupShading			= kNkMAIDCapability_VendorBase + 0x81,
	kNkMAIDCapability_Selected				= kNkMAIDCapability_VendorBase + 0x82,
	kNkMAIDCapability_ResetPrescan			= kNkMAIDCapability_VendorBase + 0x83,
	kNkMAIDCapability_MaximumChildren		= kNkMAIDCapability_VendorBase + 0x84,	//	From Nikon Scan 3.0
	kNkMAIDCapability_DriveMode				= kNkMAIDCapability_VendorBase + 0x85,	//	For LS-8000
	kNkMAIDCapability_DriveModeHelp			= kNkMAIDCapability_VendorBase + 0x86,	//	For LS-8000
	kNkMAIDCapability_DriveModeGroup		= kNkMAIDCapability_VendorBase + 0x87,	//	For LS-8000
	kNkMAIDCapability_AdaptorID				= kNkMAIDCapability_VendorBase + 0x88,	//	For LS-8000
	kNkMAIDCapability_ReverseState			= kNkMAIDCapability_VendorBase + 0x89,	//	For LS-4000
	kNkMAIDCapability_NegativeScanMode		= kNkMAIDCapability_VendorBase + 0x8A,	//	From Nikon Scan 3.1.1
	
	kNkMAIDCapability_ExtrasHelp			= kNkMAIDCapability_VendorBase + 0x90,

	kNkMAIDCapability_DurationTime			= kNkMAIDCapability_VendorBase + 0xA0,
	kNkMAIDCapability_DurationTimeHelp		= kNkMAIDCapability_VendorBase + 0xA1,
	kNkMAIDCapability_DurationTimeGroup		= kNkMAIDCapability_VendorBase + 0xA2,

	kNkMAIDCapability_RevelationEnable		= kNkMAIDCapability_VendorBase + 0xA3,	//	For LS-5000

	kNkMAIDCapability_NikonEnhancementEnable= kNkMAIDCapability_VendorBase + 0xA4,	//	For LS-5000 add sugiyama 2003/02/20
	kNkMAIDCapability_NikonEnhancementGroup	= kNkMAIDCapability_VendorBase + 0xA5,	//	For LS-5000
	kNkMAIDCapability_NikonEnhancementHelp	= kNkMAIDCapability_VendorBase + 0xA6,	//	For LS-5000
	kNkMAIDCapability_NikonEnhancementMode	= kNkMAIDCapability_VendorBase + 0xA7	//	For LS-5000
};

///////////////////////////////////////////////////////////
//	Vendor result code
//		Scanner's vendor result range is over VendorBase + 0x100.
//		0x00 - 0xFF is for camera's vendor result.
//
enum eNkMAIDResultVendor
{
	kNkMAIDResult_AutoFocusFailed			= kNkMAIDResult_VendorBase + 0x102,		//	From Nikon Scan 3.1
	kNkMAIDResult_NoFilm					= kNkMAIDResult_VendorBase + 0x103,		//	From Nikon Scan 3.1

	kNkMAIDResult_NoAction					= kNkMAIDResult_VendorBase + 0x200		//	From Nikon Scan 3.1
};

///////////////////////////////////////////////////////////
//	Vendor enumration code
//
enum eNkMAIDAdaptor				//	Adaptor IDs
{
	kNkMAIDAdaptor_None		= 0,								//	There is no adaptor or holder. (LS4000, LS40 and LS8000)
	kNkMAIDAdaptor_LS4000	= 0x04000000,						//	Base value for LS4000 and LS40 adaptors.
	kNkMAIDAdaptor_LS8000	= 0x08000000,						//	Base value for LS8000 adaptors.
	kNkMAIDAdaptor_MA		= 0x00010000,						//	Base value for MA20, FH3 and FHG1.
	kNkMAIDAdaptor_SA		= 0x00020000,						//	Base value for SA21 and SA30
	kNkMAIDAdaptor_IA		= 0x00040000,						//	Base value for IA20
	kNkMAIDAdaptor_FD		= 0x00080000,						//	Base value for SF200
	kNkMAIDAdaptor_MA20		= kNkMAIDAdaptor_LS4000 + kNkMAIDAdaptor_MA + 0x0110,	//	35mm Mount adaptor. (LS4000 and LS40)
	kNkMAIDAdaptor_FH3		= kNkMAIDAdaptor_LS4000 + kNkMAIDAdaptor_MA + 0x0120,	//	35mm Strip film holder. (LS4000 and LS40)
	kNkMAIDAdaptor_FHA1		= kNkMAIDAdaptor_LS4000 + kNkMAIDAdaptor_MA + 0x0220,	//	APS holder. (LS4000 and LS40)
	kNkMAIDAdaptor_FHG1		= kNkMAIDAdaptor_LS4000 + kNkMAIDAdaptor_MA + 0x8000,	//	Medical holder. (LS4000 and LS40)
	kNkMAIDAdaptor_SA21		= kNkMAIDAdaptor_LS4000 + kNkMAIDAdaptor_SA + 0x0121,	//	35mm strip film adaptor. (LS4000 and LS40)
	kNkMAIDAdaptor_SA30		= kNkMAIDAdaptor_LS4000 + kNkMAIDAdaptor_SA + 0x0122,	//	35mm strip film adaptor. (LS4000)
	kNkMAIDAdaptor_IA20		= kNkMAIDAdaptor_LS4000 + kNkMAIDAdaptor_IA + 0x0220,	//	APS film adaptor. (LS4000 and LS40)
	kNkMAIDAdaptor_SF200	= kNkMAIDAdaptor_LS4000 + kNkMAIDAdaptor_FD + 0x0110,	//	35mm slide mount adaptor. (LS4000)
	kNkMAIDAdaptor_FH835M	= kNkMAIDAdaptor_LS8000 + 0x0110,	//	35mm Mount holder. (LS8000)
	kNkMAIDAdaptor_FH835S	= kNkMAIDAdaptor_LS8000 + 0x0120,	//	35mm Strip film holder. (LS8000)
	kNkMAIDAdaptor_FH869M	= kNkMAIDAdaptor_LS8000 + 0x0410,	//	Brownie mount holder. (LS8000)
	kNkMAIDAdaptor_FH869S	= kNkMAIDAdaptor_LS8000 + 0x0420,	//	Brownie strip film holder. (LS8000)
	kNkMAIDAdaptor_FH869G	= kNkMAIDAdaptor_LS8000 + 0x0422,	//	Brownie strip film holder with grass. (LS8000)
	kNkMAIDAdaptor_FH869GR	= kNkMAIDAdaptor_LS8000 + 0x0426,	//	Brownie strip film rotated holder with grass. (LS8000)
	kNkMAIDAdaptor_FH816	= kNkMAIDAdaptor_LS8000 + 0x4020,	//	16mm strip film holder. (LS8000)
	kNkMAIDAdaptor_FH8G1	= kNkMAIDAdaptor_LS8000 + 0x8000	//	Medical holder. (LS8000)
};

enum eNkMAIDReverseState		//	Reverse State (LS4000 with FH3)
{
	kNkMAIDReverseState_None		= 0,						//	It is not reversed.
	kNkMAIDReverseState_Horizontal	= 1,						//	It is horizontally reversed.
	kNkMAIDReverseState_Vertical	= 2,						//	It is vertically reversed.
	kNkMAIDReverseState_Both		= 3							//	It is horizontally and vertically reversed.
};

enum eNkMAIDNegativeScanMode	//	Negative Scan Mode
{
	kNkMAIDNegativeScanMode_Original	= 0,					//	The original method of Nikon is used.
	kNkMAIDNegativeScanMode_NoProcess	= 1,					//	Nothing is processed.
};

///////////////////////////////////////////////////////////
//	Generic ...
//
#ifdef _WINDOWS
	#pragma pack( push, 4 )
#endif

typedef struct tagNkMAIDCMLProfile
{
	ULONG		ulColorSpace;		// one of eNkMAIDColorSpace
	ULONG		ulBits;				// Bit depth of the supported image by this profile.
	ULONG		ulReserved[5];
#ifdef _WINDOWS
	NkMAIDString	file;			// DOS path and filename
#else
	FSSpec		file;			// Macintosh filespec
#endif
} NkMAIDCMLProfile, FAR* LPNkMAIDCMLProfile;

#ifdef _WINDOWS
	#pragma pack( pop )
#endif

///////////////////////////////////////////////////////////
#endif
